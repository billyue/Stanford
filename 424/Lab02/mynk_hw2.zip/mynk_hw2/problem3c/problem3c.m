% problem 3c
% the compressor was modified and the output taken on the given specs.
% Since there were a lot more specs to decide, I went with release time of
% 50ms to see the effect of program dependence maximally

wavePlot('output.wav')