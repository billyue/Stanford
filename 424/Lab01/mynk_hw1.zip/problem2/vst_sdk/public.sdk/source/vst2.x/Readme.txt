Due to licensing issues, we cannot distribute the VST 2.4 SDK.

You'll have to download it yourself and put the contents of the "public_sdk/source/vst2.x/" folder here.