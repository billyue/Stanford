"""
pacfile.py -- Defines a PACFile class to handle reading and writing audio
data to an audio file holding data compressed using an MDCT-based perceptual
audio coding algorithm.  The MDCT lines of each audio channel are grouped into
bands, each sharing a single scaleFactor and bit allocation that are used to
block-floating point quantize those lines.  This class is a subclass of
AudioFile.

-----------------------------------------------------------------------
2009 Marina Bosi & Richard E. Goldberg -- All rights reserved
-----------------------------------------------------------------------

See the documentation of the AudioFile class for general use of the AudioFile
class.

Notes on reading and decoding PAC files:

The OpenFileForReading() function returns a CodedParams object containing:

    nChannels = the number of audio channels
    sampleRate = the sample rate of the audio samples
    numSamples = the total number of samples in the file for each channel
    nMDCTLines = half the MDCT block size
    nMDCTLinesShort = half the short MDCT block size (for block switching)
    nSamplesPerBlock = MDCTLines (but a name that PCM files look for)
    nScaleBits = the number of bits storing scale factors
    nMantSizeBits = the number of bits storing mantissa bit allocations
    sfBands = a ScaleFactorBands object
    sfBandsShort = a ScaleFactorBands object for the short blocks
    overlapAndAdd = decoded data from the prior block (initially all zeros)

The returned ScaleFactorBands objects, sfBands and sfBandsShort, contain an
allocation of the MDCT lines into groups that share a single scale factor and
mantissa bit allocation.  They have the following attributes available:

    nBands = the total number of scale factor bands
    nLines[iBand] = the number of MDCT lines in scale factor band iBand
    lowerLine[iBand] = the first MDCT line in scale factor band iBand
    upperLine[iBand] = the last MDCT line in scale factor band iBand

The sfBands and sfBandsShort objects are changed based on block
switching when appropriate.

Notes on encoding and writing PAC files:

When writing to a PACFile the CodingParams object passed to OpenForWriting()
should have the following attributes set:

    nChannels = the number of audio channels
    sampleRate = the sample rate of the audio samples
    numSamples = the total number of samples in the file for each channel
    nMDCTLines = half the MDCT block size
    nMDCTLinesShort = half the MDCT short block size, used in block switching
    nSamplesPerBlock = MDCTLines (but a name that PCM files look for)
    nScaleBits = the number of bits storing scale factors
    nMantSizeBits = the number of bits storing mantissa bit allocations
    targetBitsPerSample = the target encoding bit rate in units of bits per
    sample

The first three attributes (nChannels, sampleRate, and numSamples) are
typically added by the original data source (e.g. a PCMFile object) but
numSamples may need to be extended to account for the MDCT coding delay of
nMDCTLines and any zero-padding done in the final data block

OpenForWriting() will add the following attributes to be used during the
encoding process carried out in WriteDataBlock():

    sfBands = a ScaleFactorBands object
    sfBandsShort = a ScaleFactorBands object for short blocks
    priorBlock = the prior block of audio data (initially all zeros)
    priorBlockType = the prior block/window type (initially WindowType.Long)
    blockType = the prior block/window type (initially WindowType.Long)

The passed ScaleFactorBands objects, sfBands and sfBandsShort, contain an
allocation of the MDCT lines into groups that share a single scale factor and
mantissa bit allocation.  They have the following attributes available:

    nBands = the total number of scale factor bands
    nLines[iBand] = the number of MDCT lines in scale factor band iBand
    lowerLine[iBand] = the first MDCT line in scale factor band iBand
    upperLine[iBand] = the last MDCT line in scale factor band iBand

Description of the PAC File Format:

Header:

    tag                 4 byte file tag equal to "PAC "
    sampleRate          little-endian unsigned long ("<L" format in struct)
    nChannels           little-endian unsigned short("<H" format in struct)
    numSamples          little-endian unsigned long ("<L" format in struct)
    nMDCTLines          little-endian unsigned long ("<L" format in struct)
    nMDCTLinesShort     little-endian unsigned long ("<L" format in struct)
    nScaleBits          little-endian unsigned short("<H" format in struct)
    nMantSizeBits       little-endian unsigned short("<H" format in struct)
    nSFBands            little-endian unsigned long ("<L" format in struct)
    for iBand in range(nSFBands):
        nLines[iBand]   little-endian unsigned short("<H" format in struct)
    nSFBandsShort       little-endian unsigned long ("<L" format in struct)
    for iBand in range(nSFBandsShort):
        nLines[iBand]   little-endian unsigned short("<H" format in struct)

Each Data Block:  (reads data blocks until end of file hit)

    for iCh in range(nChannels):
        nBytes          little-endian unsigned long ("<L" format in struct)
        as bits packed into an array of nBytes bytes:
            blockType                               2 bits
            overallScale[iCh]                       nScaleBits bits
            for iBand in range(nSFBands):
                scaleFactor[iCh][iBand]             nScaleBits bits
                bitAlloc[iCh][iBand]                nMantSizeBits bits
                if bitAlloc[iCh][iBand]:
                    for m in nLines[iBand]:
                        mantissa[iCh][iBand][m]     bitAlloc[iCh][iBand]+1 bits
            <extra custom data bits as long as space is included in nBytes>

"""
import sys
import time
import numpy as np
from struct import unpack, calcsize, pack

# command-line parsing
from optparse import OptionParser

# base class
from lib.vendor.audiofile import AudioFile, CodingParams

# to get access to WAV file handling
from lib.vendor.pcmfile import PCMFile

# class for packing data into an array of bytes
from lib.vendor.bitpack import PackedBits, BYTESIZE

# module where the actual PAC coding functions reside
from lib.cs import codec

# defines the grouping of MDCT lines into scale factor bands
from lib.cs.psychoac import ScaleFactorBands, AssignMDCTLinesFromFreqLimits

#transient detection
from lib.cs.transient import detectTransient

from lib.cs.window import WindowType

#huffman coding
from lib.cs.huffman import EncodeHuffman, DecodeHuffman

MAX16BITS = 32767


class PACFile(AudioFile):
    """
    Handlers for a perceptually coded audio file I am encoding/decoding
    """

    # a file tag to recognize PAC coded files
    tag = 'PAC '

    def ReadFileHeader(self):
        """
        Reads the PAC file header from a just-opened PAC file and uses it to
        set object attributes.  File pointer ends at start of data portion.
        """
        # check file header tag to make sure it is the right kind of file
        tag = self.fp.read(4)
        if tag != self.tag:
            raise("Tried to read a non-PAC file into a PACFile object")

        # use struct.unpack() to load up all the header data
        (
            sampleRate,
            nChannels,
            numSamples,
            nMDCTLines,
            nScaleBits,
            nMantSizeBits,
            nMDCTLinesShort
        ) = unpack('<LHLLHHL', self.fp.read(calcsize('<LHLLLHH')))
        nBands = unpack('<L', self.fp.read(calcsize('<L')))[0]
        nLines = unpack('<' + str(nBands) + 'H', self.fp.read(
            calcsize('<' + str(nBands)+'H'))
        )
        sfBands = ScaleFactorBands(nLines)

        nBandsShort = unpack('<L', self.fp.read(calcsize('<L')))[0]
        nLinesShort = unpack('<' + str(nBandsShort) + 'H', self.fp.read(
            calcsize('<' + str(nBandsShort)+'H'))
        )
        sfBandsShort = ScaleFactorBands(nLinesShort)

        # load up a CodingParams object with the header data
        myParams = CodingParams()
        myParams.sampleRate = sampleRate
        myParams.nChannels = nChannels
        myParams.numSamples = numSamples
        myParams.nMDCTLines = myParams.nSamplesPerBlock = nMDCTLines
        myParams.nMDCTLinesShort = nMDCTLinesShort
        myParams.nScaleBits = nScaleBits
        myParams.nMantSizeBits = nMantSizeBits

        # add in scale factor band information
        myParams.sfBands = sfBands
        myParams.sfBandsShort = sfBandsShort

        # start w/o all zeroes as data from prior block to overlap-and-add for
        # output
        overlapAndAdd = []
        for iCh in range(nChannels):
            overlapAndAdd.append(np.zeros(nMDCTLines, dtype=np.float64))
        myParams.overlapAndAdd = overlapAndAdd

        # always start with long block for block switching methods.
        myParams.blockType = WindowType.Long

        myParams.samplesToWrite = None
        myParams.previousBlockType = WindowType.Long

        return myParams

    def ReadDataBlock(self, codingParams):
        """
        Reads a block of coded data from a PACFile object that has already
        executed OpenForReading() and returns those samples as reconstituted
        signed-fraction data
        """
        # loop over channels (whose coded data are stored separately) and read
        # in each data block
        data = []

        # hold data for both channels
        scaleFactor = []
        bitAlloc = []
        mantissa = []
        overallScaleFactor = []

        for iCh in range(codingParams.nChannels):
            # add location for this channel's data
            data.append(np.array([], dtype=np.float64))

            # read in string containing the number of bytes of data for this
            # channel (but check if at end of file!) will be empty if at end
            # of file
            s = self.fp.read(calcsize("<L"))
            if not s:
                # hit last block, see if final overlap and add needs returning,
                # else return nothing
                if codingParams.overlapAndAdd:
                    overlapAndAdd = codingParams.overlapAndAdd
                    # setting it to zero so next pass will just return
                    codingParams.overlapAndAdd = 0
                    return overlapAndAdd
                else:
                    return
            # not at end of file, get nBytes from the string we just read
            # read it as a little-endian unsigned long
            nBytes = unpack("<L", s)[0]

            # read the nBytes of data into a PackedBits object to unpack
            pb = PackedBits()
            # PackedBits function SetPackedData() converts strings to
            # internally-held array of bytes
            pb.SetPackedData(self.fp.read(nBytes))
            if pb.nBytes < nBytes:
                raise("Only read a partial block of coded PACFile data")

            # extract the data from the PackedBits object
            # our block/window type
            codingParams.blockType = pb.ReadBits(2)

            if codingParams.blockType == WindowType.Short:
                sfBands = codingParams.sfBandsShort
            else:
                sfBands = codingParams.sfBands

            # overall scale factor
            overallScaleFactor.append(pb.ReadBits(codingParams.nScaleBits))
            scaleFactor.append([])
            bitAlloc.append([])
            # start w/ all mantissas zero
            mantissa.append(np.zeros(codingParams.nMDCTLines, np.int32))
            # loop over each scale factor band to pack its data
            for iBand in range(sfBands.nBands):
                ba = pb.ReadBits(codingParams.nMantSizeBits)
                # no bit allocation of 1 so ba of 2 and up stored as one less
                if ba:
                    ba += 1
                # bit allocation for this band
                bitAlloc[iCh].append(ba)
                # scale factor for this band
                scaleFactor[iCh].append(pb.ReadBits(codingParams.nScaleBits))

                if bitAlloc[iCh][iBand]:
                    # if bits allocated, extract those mantissas and put in
                    # correct location in matnissa array
                    m = np.empty(sfBands.nLines[iBand], np.int32)

                    #----------huffman section---------------------
                    decodeHuffman = DecodeHuffman(
                        pb,
                        bitAlloc[iCh][iBand],
                        sfBands.nLines[iBand]
                    )
                    m = decodeHuffman
                    #----------end huffman section---------------------
                    # JENNIFER FIX for really short windows:
                    if sfBands.nLines[iBand] > 0:
                        mantissa[iCh][sfBands.lowerLine[iBand]:(
                            sfBands.upperLine[iBand]+1
                        )] = m

            # done unpacking data (end loop over scale factor bands)

            # CUSTOM DATA:
            # < now can unpack any custom data passed in the nBytes of data >
            # beware of the order that we put bits in!

            # extract sendMS bit for M/S or L/R
            codingParams.sendMS = np.zeros(sfBands.nBands)
            for i in range(sfBands.nBands):
                codingParams.sendMS[i] = pb.ReadBits(1)

        # (DECODE HERE) decode the unpacked data for both channels,
        decodedData = self.Decode(
            scaleFactor,
            bitAlloc,
            mantissa,
            overallScaleFactor,
            codingParams
        )

        # overlap-and-add first half, and append it to the data array
        # (saving other half for next overlap-and-add)
        for iCh in range(codingParams.nChannels):
            spacing = codingParams.nMDCTLines/2-codingParams.nMDCTLinesShort/2
            if codingParams.blockType == WindowType.Short:
                decodedLeft = decodedData[iCh][:codingParams.nMDCTLinesShort]
                decodedRight = decodedData[iCh][codingParams.nMDCTLinesShort:]
                decodedCenter = None
            elif codingParams.blockType == WindowType.Long:
                decodedLeft = decodedData[iCh][:codingParams.nMDCTLines]
                decodedRight = decodedData[iCh][codingParams.nMDCTLines:]
                decodedCenter = None
            elif codingParams.blockType == WindowType.Start:
                decodedLeft = decodedData[iCh][:codingParams.nMDCTLines]
                decodedCenter = decodedData[iCh][
                    codingParams.nMDCTLines:codingParams.nMDCTLines + spacing
                ]
                decodedRight = decodedData[iCh][
                    (codingParams.nMDCTLines + spacing):
                    (codingParams.nMDCTLines + spacing
                        + codingParams.nMDCTLinesShort)
                ]
            elif codingParams.blockType == WindowType.Stop:
                decodedLeft = decodedData[iCh][
                    spacing:spacing + codingParams.nMDCTLinesShort
                ]
                decodedCenter = decodedData[iCh][
                    spacing + codingParams.nMDCTLinesShort:
                    codingParams.nMDCTLines
                ]
                decodedRight = decodedData[iCh][codingParams.nMDCTLines:]

            # overlap-and-add
            newBlockToWrite = np.add(
                codingParams.overlapAndAdd[iCh], decodedLeft
            )

            # data[iCh] is prior overlapped-and-added data
            data[iCh] = np.concatenate((
                data[iCh],
                newBlockToWrite
            ))

            #add nonoverlap portion of transition windows if present
            if decodedCenter is not None:
                data[iCh] = np.concatenate((
                    data[iCh],
                    decodedCenter
                ))

            # save other half for next pass
            codingParams.overlapAndAdd[iCh] = decodedRight

        # save block type for next pass
        codingParams.previousBlockType = codingParams.blockType

        # end loop over channels, return signed-fraction samples for this block
        return data

    def WriteFileHeader(self, codingParams):
        """
        Writes the PAC file header for a just-opened PAC file and uses
        codingParams attributes for the header data.  File pointer ends at
        start of data portion.
        """
        # write a header tag
        self.fp.write(self.tag)
        # make sure that the number of samples in the file is a multiple of the
        # number of MDCT long half-blocksize, otherwise zero pad as needed
        if not codingParams.numSamples % codingParams.nMDCTLines:
            # zero padding for partial final PCM block
            codingParams.numSamples += (
                codingParams.nMDCTLines
                - codingParams.numSamples % codingParams.nMDCTLines
            )

        # also add in the delay block for the second pass w/ the
        # last half-block due to the delay in processing the first samples
        # on both sides of the MDCT block
        codingParams.numSamples += codingParams.nMDCTLines

        # write the coded file attributes
        self.fp.write(pack(
            '<LHLLHHL',
            codingParams.sampleRate,
            codingParams.nChannels,
            codingParams.numSamples,
            codingParams.nMDCTLines,
            codingParams.nScaleBits,
            codingParams.nMantSizeBits,
            codingParams.nMDCTLinesShort
        ))

        # create ScaleFactorBand objects to be used by the encoding process
        # and write their info to header
        sfBands = ScaleFactorBands(AssignMDCTLinesFromFreqLimits(
            codingParams.nMDCTLines,
            codingParams.sampleRate
        ))

        sfBandsShort = ScaleFactorBands(AssignMDCTLinesFromFreqLimits(
            codingParams.nMDCTLinesShort,
            codingParams.sampleRate
        ))

        codingParams.sfBands = sfBands
        codingParams.sfBandsShort = sfBandsShort

        self.fp.write(pack('<L', sfBands.nBands))
        self.fp.write(pack(
            '<' + str(sfBands.nBands) + 'H', * (sfBands.nLines.tolist())
        ))

        self.fp.write(pack('<L', sfBandsShort.nBands))
        self.fp.write(pack(
            '<' + str(sfBandsShort.nBands) + 'H',
            * (sfBandsShort.nLines.tolist())
        ))

        # start w/o all zeroes as prior block of unencoded data for other half
        # of MDCT block
        priorBlock = []
        for iCh in range(codingParams.nChannels):
            priorBlock.append(np.zeros(
                codingParams.nMDCTLines, dtype=np.float64
            ))
        codingParams.priorBlock = priorBlock

        # start `priorUnusedBits` at 0 so the VBR logic works properly
        codingParams.priorUnusedBits = 0

        # start with long window
        codingParams.blockType = WindowType.Long
        codingParams.blockToWrite = None
        codingParams.lastTrans = 0

        return

    def WriteDataBlock(self, data, codingParams):
        """
        Writes a block of signed-fraction data to a PACFile object that has
        already executed OpenForWriting()"""

        # combine this block of multi-channel data w/ the prior block's to
        # prepare for MDCTs twice as long
        fullBlockData = []
        for iCh in range(codingParams.nChannels):
            fullBlockData.append(np.concatenate((
                codingParams.priorBlock[iCh], data[iCh]
            )))
        # current pass's data is next pass's prior block data
        codingParams.priorBlock = data

        #previous block/window type
        codingParams.priorBlockType = codingParams.blockType

        #if codingParams.blockToWrite is None:
        codingParams.blockToWrite = fullBlockData
        #    return

        #check leading transient
        if detectTransient(data, codingParams) == 0:
            #no transient
            if (codingParams.priorBlockType == WindowType.Long) or (codingParams.priorBlockType == WindowType.Stop):
                codingParams.blockType = WindowType.Long
            elif codingParams.priorBlockType == WindowType.Start:
                codingParams.blockType = WindowType.Short	
            else: 
                codingParams.blockType = WindowType.Stop
        else:
            #transient!
            if (codingParams.priorBlockType == WindowType.Short) or (codingParams.priorBlockType == WindowType.Start):
                codingParams.blockType = WindowType.Short
            else:
                codingParams.blockType = WindowType.Start

        def encode_block(blockToWrite, sfBands):
            """Encode a single block.

            :blockToWrite: @todo
            :sfBands: @todo
            :returns: @todo

            """
            (
                scaleFactor,
                bitAlloc,
                mantissa,
                overallScaleFactor,
                sendMS
            ) = self.Encode(blockToWrite, codingParams)

            

            # for each channel, write the data to the output file
            for iCh in range(codingParams.nChannels):

                # determine the size of this channel's data block and write it
                # to the output file
                # bits for overall scale factor
                nBytes = codingParams.nScaleBits

                iMant = 0
                # huffman calculations etc.
                huffmanCoded = []
                huffmanCodedSize = 0
                for iBand in range(sfBands.nBands):
                    huffmanCodedBand = ""
                    if bitAlloc[iCh][iBand]:
                        mantissasToEncode = []
                        for j in range(sfBands.nLines[iBand]):
                            # mantissas for this band (if bit allocation
                            # non-zero) and bit alloc <> 1 so is 1 higher
                            # than the number
                            mantissasToEncode.append(mantissa[iCh][iMant+j])
                        if len(mantissasToEncode) > 0:
                            huffmanCodedString, savings = EncodeHuffman(
                                mantissasToEncode, bitAlloc[iCh][iBand]
                            )
                            codingParams.priorUnusedBits += savings
                            huffmanCodedBand += huffmanCodedString
                            iMant += sfBands.nLines[iBand]

                    huffmanCodedSize += len(huffmanCodedBand)
                    huffmanCoded.append(huffmanCodedBand)
                # add huffman BITS
                nBytes += huffmanCodedSize
                # end huffman calculation

                # for the four window types
                nBytes += 2

                # loop over each scale factor band to get its bits
                for iBand in range(sfBands.nBands):
                    # mantissa bit allocation and scale factor for that sf band
                    nBytes += (
                        codingParams.nMantSizeBits + codingParams.nScaleBits
                    )

                # CUSTOM DATA:
                # < now can add space for custom data, if desired>

                # add a bit for sending M/S or L/R bit (per channel)
                # per subband
                nBytes += sfBands.nBands

                # now convert the bits to bytes (w/ extra one if spillover
                # beyond byte boundary)
                if nBytes % BYTESIZE == 0:
                    nBytes /= BYTESIZE
                else:
                    nBytes = nBytes/BYTESIZE + 1

                # stores size as a little-endian unsigned long
                self.fp.write(pack("<L", int(nBytes)))

                # create a PackedBits object to hold the nBytes of data for
                # this channel/block of coded data
                pb = PackedBits()
                pb.Size(nBytes)

                # now pack the nBytes of data into the PackedBits object
                # window type
                pb.WriteBits(codingParams.blockType, 2)

                # overall scale factor
                pb.WriteBits(overallScaleFactor[iCh], codingParams.nScaleBits)
                # index offset in mantissa array (because mantissas w/ zero
                # bits are omitted)
                iMant = 0
                # loop over each scale factor band to pack its data
                for iBand in range(sfBands.nBands):
                    ba = bitAlloc[iCh][iBand]
                    # if non-zero, store as one less (since no bit allocation
                    # of 1 bits/mantissa)
                    if ba:
                        ba -= 1

                    # bit allocation for this band (written as one less if
                    # non-zero)
                    pb.WriteBits(ba, codingParams.nMantSizeBits)

                    # scale factor for this band (if bit allocation non-zero)
                    pb.WriteBits(
                        scaleFactor[iCh][iBand],
                        codingParams.nScaleBits
                    )
                    if bitAlloc[iCh][iBand]:
                        for bit in huffmanCoded[iBand]:
                            pb.WriteBits(int(bit), 1)
                        iMant += codingParams.sfBands.nLines[iBand]  # add to mantissa offset
    

                # done packing (end loop over scale factor bands)

                # CUSTOM DATA:
                # < now can add in custom data if space allocated in nBytes
                # above>

                # Stereo - transmitting one bit for M/S or L/R per subband
                for i in range(codingParams.sfBands.nBands):
                    pb.WriteBits(sendMS[i], 1)

                # finally, write the data in this channel's PackedBits object
                # to the output file
                self.fp.write(pb.GetPackedData())

        if codingParams.blockType == WindowType.Short:
            # we have multiple short windows to encode
            fullBlock = codingParams.blockToWrite
            spacing = codingParams.nMDCTLines/2-codingParams.nMDCTLinesShort/2
            sfBands = codingParams.sfBandsShort

            for i in range(
                codingParams.nMDCTLines / codingParams.nMDCTLinesShort
            ):
                blockToWrite = [
                    fullBlock[0][
                        spacing+i*codingParams.nMDCTLinesShort:
                        spacing+(i+2)*codingParams.nMDCTLinesShort
                    ],
                    fullBlock[1][
                        spacing+i*codingParams.nMDCTLinesShort:
                        spacing+(i+2)*codingParams.nMDCTLinesShort
                    ]
                ]
                encode_block(blockToWrite, sfBands)
        else:
            encode_block(codingParams.blockToWrite, codingParams.sfBands)
            #set for next pass
            codingParams.blockToWrite = fullBlockData

        # end loop over channels, done writing coded data for all channels
        return

    def Close(self, codingParams):
        """
        Flushes the last data block through the encoding process (if encoding)
        and closes the audio file
        """
        # determine if encoding or encoding and, if encoding, do last block
        # we are writing to the PACFile, must be encode
        if self.fp.mode == "wb":
            # we are writing the coded file -- pass a block of zeros to move
            # last data block to other side of MDCT block
            data = [
                np.zeros(codingParams.nMDCTLines, dtype=np.float),
                np.zeros(codingParams.nMDCTLines, dtype=np.float)
            ]
            self.WriteDataBlock(data, codingParams)
            # do it twice because of block switcheroo
            self.WriteDataBlock(data, codingParams)
        self.fp.close()

    def Encode(self, data, codingParams):
        """
        Encodes multichannel audio data and returns a tuple containing
        the scale factors, mantissa bit allocations, quantized mantissas,
        and the overall scale factor for each channel.
        """
        # Passes encoding logic to the Encode function defined in the codec
        # module
        return codec.Encode(data, codingParams)

    def Decode(
        self,
        scaleFactor,
        bitAlloc,
        mantissa,
        overallScaleFactor,
        codingParams
    ):
        """
        Decodes a single audio channel of data based on the values of its
        scale factors, bit allocations, quantized mantissas, and overall
        scale factor.
        """
        # Passes decoding logic to the Decode function defined in the codec
        # module
        return codec.Decode(
            scaleFactor,
            bitAlloc,
            mantissa,
            overallScaleFactor,
            codingParams
        )


def encode_and_decode(
        inputFilePath,
        codedFilePath,
        outputFilePath,
        dataRate,
        defaultCodingParams={}
    ):
    """Encode and then decode a file at a given data rate.

    :inputFilePath: @todo
    :codedFilePath: Path to coded file.
    :outputFilePath: @todo
    :dataRate: desired data rate (in kbps)
    :returns: @todo

    """
    encodeDecodeTimes = []
    for Direction in ("Encode", "Decode"):
        elapsed = time.time()
        if Direction == "Encode":
            print "\nEncoding...Please wait a while...\n",
            inFile = PCMFile(inputFilePath)
            outFile = PACFile(codedFilePath)
        else:
            print "\nDecoding...Please wait a while...\n",
            inFile = PACFile(codedFilePath)
            outFile = PCMFile(outputFilePath)
        # only difference is file names and type of AudioFile object

        # open input file
        codingParams = inFile.OpenForReading()  # (includes reading header)

        # pass parameters to the output file
        if Direction == "Encode":
            # set additional parameters that are needed for PAC file
            # (beyond those set by the PCM file on open)
            if "nMDCTLines" in defaultCodingParams:
                codingParams.nMDCTLines = defaultCodingParams["nMDCTLines"]
            else:
                codingParams.nMDCTLines = 512

            if "nMDCTLinesShort" in defaultCodingParams:
                codingParams.nMDCTLinesShort = (
                    defaultCodingParams["nMDCTLinesShort"]
                )
            else:
                codingParams.nMDCTLinesShort = 64

            codingParams.nScaleBits = 4 
            codingParams.nScaleBitsShort = 3 
            codingParams.nMantSizeBitsShort = 2 
            codingParams.nMantSizeBits = 4
            #codingParams.targetBitsPerSample = 2.9
            codingParams.targetBitsPerSample = (
                (dataRate * 1000.0) / codingParams.sampleRate
            )
            # tell the PCM file how large the block size is
            codingParams.nSamplesPerBlock = codingParams.nMDCTLines
        else:
            # set PCM parameters (the rest is same as set by PAC file on open)
            codingParams.bitsPerSample = 16
        # only difference is in setting up the output file parameters

        # open the output file
        outFile.OpenForWriting(codingParams)  # (includes writing header)

        # Read the input file and pass its data to the output file to be
        # written
        while True:
            data = inFile.ReadDataBlock(codingParams)
            if not data:
                break  # we hit the end of the input file
            outFile.WriteDataBlock(data, codingParams)
            sys.stdout.flush()
        # end loop over reading/writing the blocks

        # close the files
        inFile.Close(codingParams)
        outFile.Close(codingParams)

        elapsed = time.time()-elapsed
        print "Done.  {} seconds elapsed".format(elapsed)
        encodeDecodeTimes.append(elapsed)
    # end of loop over Encode/Decode

    return encodeDecodeTimes

###
#   Main function takes command line arguments then encodes and decodes given
#   file at provided bitrate.
###
if __name__ == "__main__":

    argParser = OptionParser(
        usage="usage: %prog [options] inFilePath outFilePath"
    )

    argParser.add_option(
        "-b",
        "--bitrate",
        dest="bitrate",
        help="Bitrate per channel to use (in kbps).  Default is 256.",
        default=256.0,
        type=float
    )

    argParser.add_option(
        "-c",
        "--codedFilePath",
        dest="codedFilePath",
        help="Path to output compressed file.  Default is outFileName.aaac"
    )

    (options, args) = argParser.parse_args()

    if len(args) == 2:
        inputFilePath = args[0]
        outputFilePath = args[1]
    else:
        argParser.print_help()
        exit(-1)

    print("""
_____________________________________
___    |__    |__    |__    |_  ____/
__  /| |_  /| |_  /| |_  /| |  /
_  ___ |  ___ |  ___ |  ___ / /___
/_/  |_/_/  |_/_/  |_/_/  |_\____/


All-American-Advanced-Audio-Codec

         ()__
         ||**Z__
         ||**|**=Z____
         ||**|**=|====|
         ||==|**=|====|
         ||\"\"|===|====|
         ||  `\"\"\"|====|
         ||      `\"\"\"\"`
    """)

    if not options.codedFilePath:
        options.codedFilePath = outputFilePath[:-3] + "aaaac"

    huffmanString = " huffman"


    print(
        "\nEncoding and decoding ({} -> {} -> {}) @ {} kbps".format(
            inputFilePath,
            options.codedFilePath,
            outputFilePath,
            options.bitrate,
        )
    )

    encode_and_decode(
        inputFilePath,
        options.codedFilePath,
        outputFilePath,
        options.bitrate,
    )
