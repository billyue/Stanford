###
#   @file       bitalloc.py
#
#               Bit allocation methods as specified in 422 homework 5.  The
#               only really useful one is the actual `BitAlloc` method.
#
#   @author     Colin Sullivan <colin [at] colin-sullivan.net>
#
#               Copyright (c) 2013 Colin Sullivan
#               Licensed under the MIT license.
###

import numpy as np


def remove_insane(bitsPerBandLines):
    """If elements in the array less than 2, set them to zero

    :bitsPerBandLines: @todo
    :returns: @todo

    """
    for i in range(len(bitsPerBandLines)):
        if bitsPerBandLines[i] < 2:
            bitsPerBandLines[i] = 0

    return bitsPerBandLines


def BitAllocUniform(bitBudget, maxMantBits, nBands, nLines, SMR):
    """
    Return a hard-coded vector that, in the case of the signal use in HW#4,
    gives the allocation of mantissa bits in each scale factor band when
    bits are uniformely distributed for the mantissas.

    :bitBudget: is total number of mantissa bits to allocate
    :maxMantBits: is max mantissa bits that can be allocated per line
    :nBands: is total number of scale factor bands
    :nLines[nBands]: is number of lines in each scale factor band
    :SMR[nBands]: is signal-to-mask ratio in each scale factor band
    :return: bits[nBands] is number of bits allocated to each scale factor band

    """

    # Since we're allocating a uniform amount of mantissa bits to each
    # line, simply need to know how many lines are in each band and use
    # this to calculate the number of mantissa bits needed for the band

    # Number of bits in each band
    numBitsPerBand = np.ones(nBands)

    # number of bits in each line when uniformly distributed
    numBitsPerLine = int(bitBudget / np.sum(nLines))

    numBitsPerBand *= numBitsPerLine

    remove_insane(numBitsPerBand)

    return np.array(numBitsPerBand).astype(np.int)

#def BitAllocConstSNR(bitBudget, maxMantBits, nBands, nLines, SMR):
    #"""
    #Return a hard-coded vector that, in the case of the signal use in HW#4,
    #gives the allocation of mantissa bits in each scale factor band when
    #bits are distributed for the mantissas to try and keep a constant
    #quantization noise floor (assuming a noise floor 6 dB per bit below
    #the peak SPL line in the scale factor band).

    #:bitBudget: is total number of mantissa bits to allocate
    #:maxMantBits: is max mantissa bits that can be allocated per line
    #:nBands: is total number of scale factor bands
    #:nLines[nBands]: is number of lines in each scale factor band
    #:SMR[nBands]: is signal-to-mask ratio in each scale factor band
    #:return: bits[nBands] is number of bits allocated to each scale factor
    # band
    #"""

    ## find band with lowest maximum
    #lowestMaximumIndex = 0
    #for b in range(1, len(maxValuePerBand)):
        #if maxValuePerBand[b] < maxValuePerBand[lowestMaximumIndex]:
            #lowestMaximumIndex = b

    ## plot band with lowest maximum
    #pylab.hlines(
        #maxValuePerBand[lowestMaximumIndex],
        #mdctBinFreqs[0],
        #mdctBinFreqs[-1],
        #label="Target noise floor"
    #)

    ## Amount of bits allocated per band line (result)
    #bitsPerBandLine = np.zeros(nBands)

    #targetNoiseFloor = maxValuePerBand[lowestMaximumIndex]

    #shouldContinueAllocating = True

    #remainingBitBudget = bitBudget

    #while shouldContinueAllocating:

        ## wether or not a bit was added to a band this round
        #bitWasAdded = False

        ## for each band
        #for b in range(nBands):
            ## calculate noise floor
            #bandNoiseFloor = (
                #maxValuePerBand[b] - (6.0 * bitsPerBandLine[b])
            #)

            #if (
                ## if noise floor is above threshold
                #bandNoiseFloor > targetNoiseFloor
                ## and we can afford to add a bit to the band
                #and remainingBitBudget - nLines[b] > 0
            #):
                ## add a bit to the band and reduce bit budget
                #bitsPerBandLine[b] += 1
                #remainingBitBudget -= nLines[b]
                #bitWasAdded = True

        ## either we ran out of bits or all bands are below threshold or we
        ## still have some bits but cant afford to lower bands.
        #if remainingBitBudget == 0 or not bitWasAdded:
            #shouldContinueAllocating = False

    #return bitsPerBandLine


def BitAllocConstSNR(bitBudget, maxMantBits, nBands, nLines, SMR):
    """
    Return a hard-coded vector that, in the case of the signal use in HW#4,
    gives the allocation of mantissa bits in each scale factor band when
    bits are distributed for the mantissas to try and keep a constant
    quantization noise floor (assuming a noise floor 6 dB per bit below
    the peak SPL line in the scale factor band).

    :bitBudget: is total number of mantissa bits to allocate
    :maxMantBits: is max mantissa bits that can be allocated per line
    :nBands: is total number of scale factor bands
    :nLines[nBands]: is number of lines in each scale factor band
    :SMR[nBands]: is signal-to-mask ratio in each scale factor band
    :return: bits[nBands] is number of bits allocated to each scale factor band

    """
    from lib.cs.window import HanningWindow, SineWindow
    from lib.cs.mdct import MDCT
    from lib.cs.psychoac import (
        AssignMDCTLinesFromFreqLimits, ScaleFactorBands
    )
    from lib.cs.normalization import SPL_MDCT

    # Create signal
    fs = 48000.0
    A = [0.45,  0.15,   0.15,   0.10,   0.06,   0.05]
    f = [440.0, 550.0,  660.0,  880.0,  4400.0, 8800.0]
    n = np.arange(0, 1024)

    x = np.zeros(len(n))

    for i in range(0, len(f)):
        x += A[i] * np.cos(2.0 * np.pi * f[i] * n / fs)

    xWindowed = HanningWindow(x)

    fftBlockSize = 1024

    # FFT
    X = np.fft.fft(xWindowed, fftBlockSize)

    # throw away right half
    X = X[:len(X) / 2.0]

    # Take MDCT
    mdctBlockSize = 1024.0
    mdctHalfBlockSize = 0.5 * mdctBlockSize
    xMDCT = MDCT(SineWindow(x), mdctHalfBlockSize, mdctHalfBlockSize)
    xMDCTSPL = SPL_MDCT(xMDCT, SineWindow(np.ones(len(n))))

    # Assign MDCT lines to frequency bands
    myBands = AssignMDCTLinesFromFreqLimits(mdctHalfBlockSize, fs)

    scaleFactorBands = ScaleFactorBands(myBands)

    # calculate max value in each critical band
    nBands = scaleFactorBands.nBands
    maxValuePerBand = np.zeros(nBands)

    bandStartLineIndex = 0
    bandEndLineIndex = 0
    for b in range(nBands):
        bandEndLineIndex = (
            bandStartLineIndex + scaleFactorBands.nLines[b]
        )

        maxValuePerBand[b] = np.amax(
            xMDCTSPL[bandStartLineIndex:bandEndLineIndex]
        )

        bandStartLineIndex = bandEndLineIndex

    # Amount of bits allocated per band line (result)
    bitsPerBandLine = np.zeros(nBands)

    shouldContinueAllocating = True

    remainingBitBudget = bitBudget

    while shouldContinueAllocating:

        ## wether or not a bit was added to a band this round
        bitWasAdded = False

        maxNoiseFloorIndex = None
        maxNoiseFloor = None

        # for each band
        for b in range(nBands):
            # if band has not yet reached the maximum bits available
            if bitsPerBandLine[b] < maxMantBits:
                # calculate noise floor
                bandNoiseFloor = (
                    maxValuePerBand[b] - (6.0 * bitsPerBandLine[b])
                )

                # find maximum noise floor
                if maxNoiseFloor is None or bandNoiseFloor > maxNoiseFloor:
                    maxNoiseFloor = bandNoiseFloor
                    maxNoiseFloorIndex = b

        # if we can afford to add a bit to the band
        if (remainingBitBudget - nLines[maxNoiseFloorIndex] > 0):
            # add a bit to the band and reduce bit budget
            bitsPerBandLine[maxNoiseFloorIndex] += 1
            remainingBitBudget -= nLines[maxNoiseFloorIndex]
            bitWasAdded = True

        # either we ran out of bits or we still have some bits but cant
        # afford to lower bands.
        if remainingBitBudget == 0 or not bitWasAdded:
            shouldContinueAllocating = False

    return remove_insane(bitsPerBandLine).astype(np.int)


def BitAllocConstMNRStereo(bitBudget, maxMantBits, nBands, nLines, SMR):
    """
    Return a hard-coded vector that, in the case of the signal use in HW#4,
    gives the allocation of mantissa bits in each scale factor band when
    bits are distributed for the mantissas to try and keep the quantization
    noise floor a constant distance below (or above, if bit starved) the
    masked threshold curve (assuming a quantization noise floor 6 dB per
    bit below the peak SPL line in the scale factor band).

    :bitBudget: is total number of mantissa bits to allocate for two channels
    :maxMantBits: is max mantissa bits that can be allocated per line
    :nBands: is total number of scale factor bands
    :nLines[nBands]: is number of lines in each scale factor band
    :SMR[iCh][nBands]: is signal-to-mask ratio in each scale factor band per channel
    :return: bits[nBands] is number of bits allocated to each scale factor band

    """
    # Amount of bits allocated per band line (result)
    bitsPerBandLine = np.zeros(2*nBands)

    shouldContinueAllocating = True

    remainingBitBudget = bitBudget

    # stereo SMR array
    stereoSMR = np.concatenate((SMR[0], SMR[1]))

    while shouldContinueAllocating:

        # wether or not a bit was added to a band this round
        bitWasAdded = False

        maxNoiseFloorIndex = None
        maxNoiseFloor = None

        # for each band for each channel
        for b in range(nBands*2):
            # if band has not yet reached the maximum bits available
            if bitsPerBandLine[b] < maxMantBits:

                # calculate noise floor with current allocation
                bandNoiseFloor = (
                    stereoSMR[b] - (6.0 * bitsPerBandLine[b])
                )

                # find maximum noise floor
                if maxNoiseFloor is None or bandNoiseFloor > maxNoiseFloor:
                    maxNoiseFloor = bandNoiseFloor
                    maxNoiseFloorIndex = b
    
        # the band with the maximum noise floor has not reached the maximum
        # available bits
        if maxNoiseFloorIndex is not None:
            # if we can afford to add a bit to the band
            if ((remainingBitBudget - nLines[maxNoiseFloorIndex % nBands]) > 0):
                # add a bit to the band and reduce bit budget
                bitsPerBandLine[maxNoiseFloorIndex] += 1
                remainingBitBudget -= nLines[maxNoiseFloorIndex % nBands]
                bitWasAdded = True

        # either we ran out of bits or we still have some bits but cant
        # afford to lower bands.
        if remainingBitBudget <= 0 or not bitWasAdded:
            shouldContinueAllocating = False

    bitsPerBandLine = np.array(remove_insane(bitsPerBandLine)).astype(np.int)
    bitsPerBandLinePerChannel = [ 
        bitsPerBandLine[0:nBands],
        bitsPerBandLine[nBands:2*nBands]
        ]

    return bitsPerBandLinePerChannel


def BitAlloc(bitBudget, maxMantBits, nBands, nLines, SMR):
    """
    Allocates bits to scale factor bands so as to flatten the NMR across the
    spectrum

    :bitBudget: is total number of mantissa bits to allocate for either channel
    :maxMantBits: is max mantissa bits that can be allocated per line
    :nBands: is total number of scale factor bands
    :nLines[nBands]: is number of lines in each scale factor band
    :SMR[2][nBands]: is signal-to-mask ratio in each scale factor band per
    channel
    :return: bits[2][nBands] is number of bits allocated to each scale factor
    band per channel

    Logic:
       Maximizing SMR over blook gives optimization result that:
           R(i) = P/N + (1 bit/ 6 dB) * (SMR[i] - avgSMR)
       where P is the pool of bits for mantissas and N is number of bands
       This result needs to be adjusted if any R(i) goes below 2 (in which
       case we set R(i)=0) or if any R(i) goes above maxMantBits (in
       which case we set R(i)=maxMantBits).  (Note: 1 Mantissa bit is
       equivalent to 0 mantissa bits when you are using a midtread quantizer.)
       We will not bother to worry about slight variations in bit budget due
       rounding of the above equation to integer values of R(i).
    """
    alloc = BitAllocConstMNRStereo(
        bitBudget, maxMantBits, nBands, nLines, SMR
        )

        #BitAllocConstMNRSingleChannel(
        #    0.5 * bitBudget, maxMantBits, nBands, nLines, SMR[0]
        #),
        #BitAllocConstMNRSingleChannel(
        #    0.5 * bitBudget, maxMantBits, nBands, nLines, SMR[1]
        #)

    return alloc
    
