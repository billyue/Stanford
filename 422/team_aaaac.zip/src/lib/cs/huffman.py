"""
huffman.py -- Does huffman encoding and decoding as part of an audio coder

Written by Mayank as part of Team AAAC for Marina Bosi's CCRMA Music 422 class.

"""
# TODO: ask colin about using vendor things here..
from bitpack import *
import operator
import math


# Helper classes

class Node:
    """
    Helper class that stores and adds nodes for Huffman tree creation
        
    """
    def __init__(self):
        """
            Default values:
                Count - frequency of occurence
                Children - If it has children
            Possible added Ivar:
                value - added only if node is leaf
        """
        self.count = 0
        self.children = {}
    
    def setTerminalNode(self, value, count):
        """
            Set node as leaf by storing value and frequency
            """
        
        self.value = value
        self.count = count
    
    def setLeftChild(self, node):
        """
            Set left child to given node and increment frequency of node
        """
        self.children[0] = node
        self.count += node.count
    
    def setRightChild(self, node):
        """
            Set right child to given node and increment frequency of node
        """
        self.children[1] = node
        self.count += node.count
    
    def __str__(self):
        """
            Allows for printing of node to inspect state
        """

        if len(self.children) == 0:
            return str(self.value) + ':' +str(self.count)
        else:
            return 'L:' + str(self.children[0]) + ' R' + str(self.children[1])

class HuffmanDecoder:
    """
        Class that helps decode huffman encoded data
    """

    def __init__(self, dict):
        """
            Initialize with a binaryToValue dictionary
        """
        self.binaryToValue = dict
        self.state = ''

    def DecodeBit(self, bit):
        """
            Decode bit-by-bit. Store in state if not found
            Return value:
                (found huffman code, value)
        """
        self.state += str(bit)
        for key in self.binaryToValue:
            if key == self.state:
                self.state = ''
                return True, self.binaryToValue[key]
        return False, 'none'



class HuffmanEncoder:
    """
        Class that helps encode data using Huffman algorithm
    """

    def __init__(self, array, originalBitsPerValue):
        """
            Initialize with array and bits per value used for original storage
        """
        # Store data
        self.data = array
        self.originalBitsPerValue = originalBitsPerValue
        self.originalDataSize = len(array) * originalBitsPerValue
        
        #Create Huffman dictionary
        self.stats = GetStats(array)
        self.tree = self.CreateTree()
        (self.binaryToValue, self.valueToBinary) = self.CreateDictionaries()
        self.finalDataSize = self.GetSize()
    
    
    def GetEncodedTable(self):
        """
            Return string of encoded table
        """
        encodedTable = ''

        # TODO: optimize size of table
        encodedTable += NumberToBinary(len(self.binaryToValue),10)
        
        # get max length of string and max value
        maxLengthOfString = len(max(self.binaryToValue.keys(), key=len))
        maxValue = max(self.binaryToValue.values())
        bitsForMaxLengthOfString = int(math.ceil(math.log((1 + maxLengthOfString),2)))
        bitsForMaxValue = int(math.ceil(math.log((1 + maxValue),2)))
        
        # TODO: use this - optimization
        bitsForMaxValue = min(bitsForMaxValue, self.originalBitsPerValue)
        # TODO : optimize here
        encodedTable += NumberToBinary(bitsForMaxLengthOfString,10)

        encodedTable += NumberToBinary(bitsForMaxValue,10)
    
        self.encodedTable = encodedTable

        self.bitsForMaxLengthOfString = bitsForMaxLengthOfString
        self.bitsForMaxValue = bitsForMaxValue
        return encodedTable

    
    def GetEncodedData(self):
        encodedData = ''
        
        if self.bitsForMaxLengthOfString == 0:
            # TODO: optimize here
            encodedData += NumberToBinary(self.data[0],16)
            encodedData += NumberToBinary(len(self.data),16)
        
        else:
            # write table
            table = self.binaryToValue
            for key in table:
                # write binary 1by1
                lengthOfKey = len(key)
                encodedData += NumberToBinary(lengthOfKey, self.bitsForMaxLengthOfString)
                for letter in key:
                    encodedData += letter
                # write num
                encodedData += NumberToBinary(table[key],self.bitsForMaxValue)
            tableSize = len(encodedData)
            # write values
            dataStream = ''
            for item in self.data:
                value = item
                binaryCode = self.valueToBinary[value]
                dataStream += binaryCode
            dataStreamSize = len(dataStream)
                    
            encodedData += NumberToBinary(dataStreamSize,32)
            for bit in dataStream:
                encodedData += bit
        self.encodedData = encodedData
        return self.encodedData
    
    
    
    def CreateDictionaries(self):
        """
            Create Dictionaries for huffman tree
        """
        
        binaryToValue = {}
        ConvertToDict(binaryToValue, self.tree, '')
        valueToBinary = dict((v,k) for k, v in binaryToValue.iteritems())
        return (binaryToValue, valueToBinary)
    
    def GetSize(self):
        """
            Get size of huffman encoded data
        """
        size = 0
        if len(self.stats) == 1: # special case of only one value
            size = 32        
        else:
            for key in self.stats:
                size += self.stats[key] * len(self.valueToBinary[key])
        return size
    
    def CreateTree(self):
        """
            Create Huffman algorithm tree
        """
        # add all single nodes to queue
        nodeQueue = []
        for key in self.stats:
            node = Node()
            node.setTerminalNode(key,self.stats[key])
            nodeQueue.append(node)

        while len(nodeQueue) > 1:
            node1 = self.GetMinimumNode(nodeQueue)
            node2 = self.GetMinimumNode(nodeQueue)
            node3 = Node()
            node3.setLeftChild(node1)
            node3.setRightChild(node2)
            nodeQueue.append(node3)
        # return root
        return nodeQueue[0]

    def GetMinimumNode(self, nodeQueue):
        """
            Helper function - Get minimum node while creating tree
        """
        minIndex = -1
        minValue = len(self.data)
        for i in range(len(nodeQueue)):
            item = nodeQueue[i]
            if (item.count < minValue):
                minIndex = i
                minValue = item.count
        node = nodeQueue[minIndex]
        nodeQueue.pop(minIndex)
        return node



def NumberToBinary(number, numBits):
    stringList = []
    binString = bin(number)
    
    for i in range(numBits):
        stringList.append('0')
    lenBinString = len(binString)
    for i in range(lenBinString):
        
        if binString[lenBinString - i - 1] == '1':
            if numBits - i - 1 >= 0:
                stringList[numBits - i - 1] = '1'
    return "".join(stringList)



def ConvertToDict(outputDict, node, prefix):
    """
        Given a Huffman tree, convert to dictionary
        Dictionary is output but passed as reference
    """
    if len(node.children) == 0:
        outputDict[prefix] = node.value
    else:
        ConvertToDict(outputDict, node.children[0], prefix + '0')
        ConvertToDict(outputDict, node.children[1], prefix + '1')


def GetStats(array):
    """
        Get frequency stats for an array
    """

    stats = {}
    for i in range(len(array)):
        key = array[i]
        if key in stats:
            stats[key] += 1
        else:
            stats[key] = 1
    return stats


# huffman header info - isHuffman, sizeOfTable(10bits), numBitsOfString, numBitsOfValue

def EncodeHuffman(data, bitsPerDataItem):
    if len(data) == 0:
        return ''
    
    if len(data) < 7:
        encodedDataStream = ''
        for item in data:
            encodedDataStream += NumberToBinary(item,bitsPerDataItem)
        return encodedDataStream, 0


    encodedDataStream = ''
    
    h = HuffmanEncoder(data, bitsPerDataItem)
    
    encodedTable = h.GetEncodedTable()
    encodedData = h.GetEncodedData()


    
    originalSize = h.originalDataSize
    encodedSize = len(encodedTable) + len(encodedData)
    
    if (encodedSize < originalSize):
        # yes huffman
        encodedDataStream += str(1)
        encodedDataStream += (encodedTable + encodedData)
    else:
        # no huffman
        encodedDataStream += str(0)
        for item in data:
            encodedDataStream += NumberToBinary(item, bitsPerDataItem)
    
    originalSize = h.originalDataSize
    finalSize = len(encodedDataStream)
    savedBits = originalSize - finalSize

    doubleCompressedDataStream, doubleCompressedSavings = EncodeBinaryStringInPairs(encodedDataStream)
    totalSavings = savedBits + doubleCompressedSavings
    return doubleCompressedDataStream, totalSavings


def DecodeHuffman(binaryData, bitsPerDataItem, numItems):
    if numItems == 0:
        return []
    if numItems < 7:
        pb = binaryData
        array = []
        for i in range(numItems):
            item = pb.ReadBits(bitsPerDataItem)
            array.append(item)
        return array
        
    singleCompressedHuffmanStream = DecodeBinaryStringInPairsFromData(binaryData)
    array = DecodeHuffmanString(singleCompressedHuffmanStream, bitsPerDataItem, numItems)
    return array
    

# NOT WORKING RIGHT NOW - NO GUARD FOR length of items <7 and 0
def DecodeHuffmanFromDataStream(binaryData, bitsPerDataItem, numItems):
    pb = binaryData
#    pb.ResetPointers()
    isHuffman = pb.ReadBits(1)
    array = []
    
    if (isHuffman):
        binaryToValue = {}
        # read header
        sizeTable = pb.ReadBits(10) # get table length
#        print sizeTable
        bitsForMaxLengthOfString = pb.ReadBits(10)
        bitsForMaxValue = pb.ReadBits(10)
#        print bitsForMaxLengthOfString, bitsForMaxValue
        

        
        if bitsForMaxLengthOfString == 0:
            item = pb.ReadBits(16)
            numItems = pb.ReadBits(16)
            for i in range(numItems):
                array.append(item)
        else:
            # read table
            for i in range(sizeTable):
                # JENNIFER FIX: for short windows when there isn't anything
                if numItems > 0:
                    lengthOfKey = pb.ReadBits(bitsForMaxLengthOfString)
                else:
                    lengthOfKey = 0
                key = ''
                for j in range(lengthOfKey):
                    letter = pb.ReadBits(1)
                    key += str(letter)
                value = pb.ReadBits(bitsForMaxValue)
                binaryToValue[key] = value
            # read values
            lengthOfDataStream = pb.ReadBits(32)
            dataStream = ''
            for i in range(lengthOfDataStream):
                dataStream += str(pb.ReadBits(1))
#            print dataStream

            # decode huffman
            decoder = HuffmanDecoder(binaryToValue)
            for bit in dataStream:
                found, value = decoder.DecodeBit(bit)
                if found == True:
                    array.append(value)
    else:
        for i in range(numItems):
            item = pb.ReadBits(bitsPerDataItem)
            array.append(item)
    return array

def DecodeHuffmanString(dataString, bitsPerDataItem, numItems):
    pointer = 0
    isHuffman = int(dataString[pointer])
    pointer += 1
    array = []
    
    if (isHuffman):
        binaryToValue = {}
        # read header
        sizeTable = int(dataString[pointer:pointer+10],2)
        pointer += 10
        
        bitsForMaxLengthOfString = int(dataString[pointer:pointer+10],2)
        pointer += 10
        
        bitsForMaxValue = int(dataString[pointer:pointer+10],2)
        pointer += 10
        
        if bitsForMaxLengthOfString == 0:
            item = int(dataString[pointer:pointer+16],2)
            pointer += 16
            numItems = int(dataString[pointer:pointer+16],2)
            pointer += 16
            for i in range(numItems):
                array.append(item)
        else:
            # read table
            for i in range(sizeTable):
                lengthOfKey = int(dataString[pointer:pointer+bitsForMaxLengthOfString],2)
                pointer += bitsForMaxLengthOfString
                key = ''
                for j in range(lengthOfKey):
                    letter = dataString[pointer:pointer+1]
                    pointer += 1
                    key += letter
                value = int(dataString[pointer:pointer+bitsForMaxValue],2)
                pointer += bitsForMaxValue
                binaryToValue[key] = value
            # read values
            lengthOfDataStream = int(dataString[pointer:pointer+32],2)
            pointer += 32
            
            dataStream = ''
            for i in range(lengthOfDataStream):
                dataStream += dataString[pointer]
                pointer += 1
            # decode huffman
            decoder = HuffmanDecoder(binaryToValue)
            for bit in dataStream:
                found, value = decoder.DecodeBit(bit)
                if found == True:
                    array.append(value)
    else:
        for i in range(numItems):
            item = int(dataString[pointer:pointer+bitsPerDataItem],2)
            pointer += bitsPerDataItem
            array.append(item)
    
    return array


def GetRegularTables():
    binaryToValue = []
    valueToBinary = []
    for i in range(4):
        binaryToValue.append(0)
        valueToBinary.append(0)
    
    binaryToValue[0] = {'00':0,'01':1,'10':2,'11':3}
    binaryToValue[1] = {'0':0,'10':1,'110':2,'111':3}
    binaryToValue[2] = {'0':0,'110':1,'10':2,'111':3}
    binaryToValue[3] = {'0':0,'110':1,'111':2,'10':3}

    for i in range(4):
        valueToBinary[i] = dict((v,k) for k, v in binaryToValue[i].iteritems())

    return (binaryToValue,valueToBinary)


def EncodeBinaryStringInPairs(string):
    (binaryToValue,valueToBinary) = GetRegularTables()
    listOfPairs = []
    pair = ''
    encodedString = ''
    if len(string)%2 == 0:
        encodedString += '0'    # discardListBit ?
    else:
        encodedString += '1'
        string += '0'
    # create values
    for letter in string:
        pair += letter
        if len(pair) == 2:
            listOfPairs.append(int(pair,2))
            pair = ''

    #choose optimal table
    encodedDataForTable = []
    optimumTableSize = 32676
    optimumTable = 0
    for tableNumber in range(4):
    #encode table number and data
        encodedDataForTable.append('')
        for item in listOfPairs:
            encodedDataForTable[tableNumber] += valueToBinary[tableNumber][item]
        if len(encodedDataForTable[tableNumber]) < optimumTableSize:
            optimumTableSize = len(encodedDataForTable[tableNumber])
            optimumTable = tableNumber
    encodedString += NumberToBinary(optimumTable,2)
    lengthOfData = len(encodedDataForTable[optimumTable])
    bitsToReadForLength = int(math.ceil(math.log((1 + lengthOfData),2)))
    encodedString += NumberToBinary(bitsToReadForLength,4)
    encodedString += NumberToBinary(lengthOfData,bitsToReadForLength) #size of data
    encodedString += encodedDataForTable[optimumTable]
    savings = len(string) - len(encodedString)
    return encodedString, savings



def DecodeBinaryStringInPairsFromData(binaryData):
    pb = binaryData
    (binaryToValue,valueToBinary) = GetRegularTables()
    pointer = 0
    discardLastBit = pb.ReadBits(1)
    tableNumber = pb.ReadBits(2)
    # decode data
    listOfPairs = []
    state = ''
    bitsToReadForLength = pb.ReadBits(4)
    lengthOfDataStream = pb.ReadBits(bitsToReadForLength)
    for i in range(lengthOfDataStream):
        state += str(pb.ReadBits(1))
        if state in binaryToValue[tableNumber]:
            item = binaryToValue[tableNumber][state]
            listOfPairs.append(item)
            state = ''
    # convert pairs to decoded string
    string = ''
    for item in listOfPairs:
        string += NumberToBinary(item,2)
    if discardLastBit == 1:
        string = string[:-1]
    return string




def DecodeBinaryStringInPairs(encodedString):
    (binaryToValue,valueToBinary) = GetRegularTables()
    pointer = 0
    discardLastBit = int(encodedString[pointer])
    pointer += 1
    tableNumber = int(encodedString[pointer:pointer+2],2)
    pointer += 2
    # decode data
    listOfPairs = []
    state = ''
    # TODO: check
    bitsToReadForLength = int(encodedString[pointer:pointer+4],2)
    pointer += 4
    lengthOfDataStream = int(encodedString[pointer:pointer+bitsToReadForLength],2)
    pointer += bitsToReadForLength
    for i in range(lengthOfDataStream):
        state += encodedString[pointer]
        pointer += 1
        if state in binaryToValue[tableNumber]:
            item = binaryToValue[tableNumber][state]
            listOfPairs.append(item)
            state = ''
    # convert pairs to decoded string
    string = ''
    for item in listOfPairs:
        string += NumberToBinary(item,2)

    if discardLastBit == 1:
        string = string[:-1]

    return string
