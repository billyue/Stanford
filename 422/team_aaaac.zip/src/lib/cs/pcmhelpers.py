###
#   @file       pcmhelpers.py 
#
#               Some helper wrappers when opening the typical input / output
#               PCM file configurations.
#
#   @author     Colin Sullivan <colin [at] colin-sullivan.net>
#
#               Copyright (c) 2013 Colin Sullivan
#               Licensed under the MIT license.
###

import os
from ..vendor.pcmfile import PCMFile

def open_files(AUDIO_DIR, inFileName, outFileName, blockSize=1024):
    """Opens PCM files for reading and writing.

    :inFileName: The name of the input file in AUDIO_DIR
    :outFileName: The name of the output file in AUDIO_DIR
    :returns: [inFile, outFile, codingParams]

    """
    # input audio file to use for test
    inFile = PCMFile(os.path.join(AUDIO_DIR, inFileName))

    # output audio file
    outFile = PCMFile(os.path.join(AUDIO_DIR, outFileName))

    # open input file and get its coding parameters
    codingParams = inFile.OpenForReading()

    # set additional coding parameters that are needed for encoding/decoding
    codingParams.nSamplesPerBlock = blockSize

    # open the output file for writing, passing needed format/data parameters
    outFile.OpenForWriting(codingParams)

    return [inFile, outFile, codingParams]


def close_files(inFile, outFile, codingParams):
    """Close input and output files.

    :inFile: @todo
    :outFile: @todo
    :returns: @todo

    """
    # close the files
    inFile.Close(codingParams)
    outFile.Close(codingParams)
