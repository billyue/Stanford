
import numpy as np


def SPL_dft(Y, w):
    """Get SPL of a DFT signal

    :Y: The spectrum we are calculating the SPL of
    :w: the window used on the time-domain signal for that spectrum.
    :returns: the SPL for the spectrum

    """
    signalAbsVec = np.absolute(Y)
    signalPowerVec = signalAbsVec * signalAbsVec

    wN = len(w)
    wSquaredBias = (1.0 / wN) * np.sum(w * w)

    spls = []

    scale = 4.0 / ((wN ** 2.0) * wSquaredBias)

    for signalPower in signalPowerVec:
        if signalPower != 0.0:
            spls.append(
                max( 96.0 + 10.0 * np.log10(scale * signalPower), -30 )
            )
        else:
            # spls.append(96.0)
            spls.append(
                max( 96.0 + 10.0 * np.log10(scale * np.spacing(1)), -30 )
            )

    return np.asarray(spls)


def SPL_MDCT(Y, w):
    """Compute SPL of MDCT data that was windowed with w.

    :w: @todo
    :Y: @todo
    :returns: @todo

    """
    wN = len(w)
    signalAbsVec = np.absolute(Y)
    signalPowerVec = signalAbsVec * signalAbsVec * wN * wN / 4

    wSquaredBias = (1.0 / wN) * np.sum(w * w)

    spls = []

    scale = 8.0 / ((wN ** 2.0) * wSquaredBias)

    for signalPower in signalPowerVec:
        if signalPower != 0.0:
            spls.append(
                max( 96.0 + 10.0 * np.log10(scale * signalPower), -30 )
            )
        else:
            #spls.append(96.0)
            spls.append(
                max( 96.0 + 10.0 * np.log10(scale * np.spacing(1)), -30 )
            )

    return np.asarray(spls)
