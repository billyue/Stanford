"""
window.py -- Defines functions to window an array of data samples.

Written by Tim O'Brien as part of Marina Bosi's CCRMA Music 422 class.

"""

import numpy as np
from numpy import i0
pi = np.pi

def SineWindow(dataSampleArray):
    """
    Returns a copy of the dataSampleArray sine-windowed
    Sine window is defined following pp. 106-107 of
    Bosi & Goldberg, "Introduction to Digital Audio..." book
    """

    N = len(dataSampleArray)
    winIter = (np.sin(pi*(n+0.5)/N) for n in range(N))
    window = np.fromiter(winIter, np.float64)
    return window * dataSampleArray

def HanningWindow(dataSampleArray):
    """
    Returns a copy of the dataSampleArray Hanning-windowed
    Hann window is defined following pp. 106-107 of
    Bosi & Goldberg, "Introduction to Digital Audio..." book
    """
    
    N = len(dataSampleArray)
    winIter = (0.5*(1.0-np.cos(2.0*pi*(n+0.5)/N)) for n in range(N))
    window = np.fromiter(winIter, np.float64)
    return window * dataSampleArray
    
def KBDWindow(dataSampleArray,alpha=4.):
    """
    Returns a copy of the dataSampleArray, KBD-windowed.
    KBD window is defined following pp. 108-109 and pp. 117-118 of
    Bosi & Goldberg, "Introduction to Digital Audio..." book
    """
    from numpy import i0
    N         = len(dataSampleArray)
    kb        = np.arange(N/2+1) #from 0 to N/2 (N/2 + 1 samples)
    kb        = i0(pi*alpha*np.sqrt(1.-(4.*kb/N - 1.)**2))/i0(pi*alpha)
    #normalize - see text p. 117
    kbd       = np.zeros(N)
    divisor   = np.sum(kb)
    #print N
    #print "kb: {}".format(kb)
    kbd[:N/2] = np.cumsum(kb[:-1])/divisor #1st half is normalized running sum
    kbd[N/2:] = kbd[:N/2][::-1] #2nd half is reverse of first half
    kbd       = np.sqrt(kbd)
    return kbd*dataSampleArray

def KBDStartWindow(data, nLong, nShort, aLong=4., aShort=4.):
    """
    Returns an asymmetrically windowed copy of the dataSampleArray.
    KBD window is defined following pp. 108-109 and pp. 117-118 of
    Bosi & Goldberg, "Introduction to Digital Audio..." book.
    The start and stop windows are based on Edler's perfect reconstruction
    solution (book p. 133).
    """
    #if nLong<nShort:
    #    temp = nShort
    #    nShort = nLong
    #    nLong = temp
    
    #kbLong = np.arange(nLong+1) #from 0 to nLong (nLong + 1 samples)
    #kbLong = i0(pi*aLong*np.sqrt(1.-((kbLong-0.5*nLong)/(0.5*nLong))**2))/i0(pi*aLong)
    #kbLong = np.sqrt(np.cumsum(kbLong[:-1])/np.sum(kbLong))

    #kbShort = np.arange(nShort+1) #from 0 to nShort (nShort + 1 samples)
    #kbShort = i0(pi*aShort*np.sqrt(1.-((kbShort-0.5*nShort)/(0.5*nShort))**2))/i0(pi*aShort)
    #kbShort = np.sqrt(np.cumsum(kbShort[:-1])/np.sum(kbShort))
    #kbShort = kbShort[::-1] #reverse it

    #spacing = nLong/2-nShort/2

    #kbdStart = np.concatenate([kbLong, np.ones(spacing), kbShort, np.zeros(spacing)])

    return designKBDStartWindow(data, nLong, nShort, aLong, aShort)*data

def KBDStopWindow(data, nShort, nLong, aShort=4., aLong=4.):
    #return KBDStartWindow(data, nLong, nShort, aLong, aShort)[::-1]
    return designKBDStartWindow(data, nLong, nShort, aLong, aShort)[::-1]*data

def designKBDStartWindow( data, nShort, nLong, aShort=4., aLong=4.):
    if nLong<nShort:
        temp = nShort
        nShort = nLong
        nLong = temp
    
    kbLong = np.arange(nLong+1) #from 0 to nLong (nLong + 1 samples)
    kbLong = i0(pi*aLong*np.sqrt(1.-((kbLong-0.5*nLong)/(0.5*nLong))**2))/i0(pi*aLong)
    kbLong = np.sqrt(np.cumsum(kbLong[:-1])/np.sum(kbLong))

    kbShort = np.arange(nShort+1) #from 0 to nShort (nShort + 1 samples)
    kbShort = i0(pi*aShort*np.sqrt(1.-((kbShort-0.5*nShort)/(0.5*nShort))**2))/i0(pi*aShort)
    kbShort = np.sqrt(np.cumsum(kbShort[:-1])/np.sum(kbShort))
    kbShort = kbShort[::-1] #reverse it

    spacing = nLong/2-nShort/2

    kbdStart = np.concatenate([kbLong, np.ones(spacing), kbShort, np.zeros(spacing)])

    return kbdStart

class WindowType:
    Long, Start, Short, Stop = range(4)

#-----------------------------------------------------------------------------

if __name__ == "__main__":
    import matplotlib.pyplot as plt
    N = 1024
    M = N/8
    data = np.ones(N)

    #############################
#    plt.figure()
#    plt.hold(True)
#    alphas = [2.0, 3.0,4.0,7.0]
#    for alpha in alphas:
#        plt.plot(KBDWindow(data, alpha))
#    plt.plot(SineWindow(data),'r--')
#    plt.plot(HanningWindow(data), 'g--')
#    plt.grid(True)
#    plt.xlim([0,N])
#    plt.title('Windows')
#    plt.legend(['alpha=' + str(alphas[0]), 'alpha=' + str(alphas[1]), 'alpha=' + str(alphas[2]), 'alpha=' + str(alphas[3]), 'Sine','Hanning'])
#    plt.show()

    #############################   
    # Example start window
    #############################   
#    plt.figure()
#    plt.plot(np.arange(N), KBDStartWindow(data, N/2, M/2), 'b')
#    plt.grid(True)
#    plt.hold(True)
#    plt.fill_between(np.arange(N), KBDStartWindow(data, N/2, M/2),0,color='b',alpha=0.5)
#    plt.xlim([0, N])
#    plt.xticks(np.arange(5)*N/4,["0","N/4","N/2","3N/4","N"])
#    plt.title("Start Window")
#    plt.xlabel("Samples")
#    plt.ylabel("Amplitude")
#    plt.show()

    #############################   
    # Example stop window
    #############################   
#    plt.figure()
#    plt.plot(np.arange(N), KBDStopWindow(data, M/2, N/2), 'r')
#    plt.grid(True)
#    plt.hold(True)
#    plt.fill_between(np.arange(N), KBDStopWindow(data, M/2, N/2), 0,color='r',alpha=0.5)
#    plt.xlim([0, N])
#    plt.xticks(np.arange(5)*N/4,["0","N/4","N/2","3N/4","N"])
#    plt.title("Stop Window")
#    plt.xlabel("Samples")
#    plt.ylabel("Amplitude")
#    plt.show()



    #############################    
    plt.figure()
    plt.plot(np.arange(N/2), KBDWindow(data)[N/2:], 'g',alpha=0.5)
    plt.fill_between(np.arange(N/2), KBDWindow(data)[N/2:], 0, color='g',alpha=0.3)
    plt.plot(np.arange(N/2)+3*N/2, KBDWindow(data)[:N/2], 'g',alpha=0.5)
    plt.fill_between(np.arange(N/2)+3*N/2, KBDWindow(data)[:N/2], 0, color='g',alpha=0.3)

    plt.plot(np.arange(N), KBDStartWindow(data, N/2, M/2), 'b')
    plt.grid(True)
    plt.hold(True)
    plt.fill_between(np.arange(N), KBDStartWindow(data, N/2, M/2),0,color='b',alpha=0.5)
    plt.plot(np.arange(N)+N, KBDStopWindow(data, M/2, N/2), 'b')
    plt.fill_between(np.arange(N)+N, KBDStopWindow(data, M/2, N/2),0,color='b',alpha=0.5)
    spacing = N/4-M/4
    colors = ['r','g']
    for i in range(N/M):
      plt.plot(np.arange(M)+N/2+spacing+i*M/2, KBDWindow(data[:M]), colors[i%len(colors)])
      plt.fill_between(np.arange(M)+N/2+spacing+i*M/2, KBDWindow(data[:M]),0,color=colors[i%len(colors)],alpha=0.5)
    plt.xticks(np.arange(len(data)*2/128+1)*128)
    plt.xlim([0, 2*N])
    plt.xticks(np.arange(9)*N/4,["0","N/4","N/2","3N/4","N","5N/4","3N/2","7N/4","2N"])
    plt.title("Start and Stop Window Sequence")
    plt.xlabel("Samples")
    plt.ylabel("Amplitude")
    plt.show()

    plt.figure()
    plt.plot(np.arange(128), KBDWindow(np.ones(128)), 'b', alpha=0.8)
    plt.show()

    #############################
#    plt.figure()
#    plt.plot(np.arange(N), KBDStartWindow(data, N/2, M/2), 'b')
#    plt.grid(True)
#    plt.hold(True)
#    plt.fill_between(np.arange(N), KBDStartWindow(data, N/2, M/2),0,color='b',alpha=0.5)
#    plt.plot(np.arange(N)+N/2, KBDStopWindow(data, M/2, N/2), 'b')
#    plt.fill_between(np.arange(N)+N/2, KBDStopWindow(data, M/2, N/2),0,color='b',alpha=0.5)
#    #spacing = N/4-M/4
#    plt.xticks(np.arange(len(data)*3/(2*128)+1)*128)
#    plt.xlim([0, 3*len(data)/2])
#    plt.title("Start and Stop Window Sequence")
#    plt.xlabel("Samples")
#    plt.ylabel("Amplitude")
#    plt.show()

    #############################
#    plt.figure()
#    #plt.plot(np.arange(N), KBDStartWindow(data, N/2, M/2), 'b')
#    plt.grid(True)
#    plt.hold(True)
#    #plt.fill_between(np.arange(N), KBDStartWindow(data, N/2, M/2),0,color='b',alpha=0.5)
#    for i in range(N/M):
#      plt.plot(np.arange(M)+spacing+i*M/2, KBDWindow(data[:M]), colors[i%len(colors)])
#      plt.fill_between(np.arange(M)+spacing+i*M/2, KBDWindow(data[:M]),0,color=colors[i%len(colors)],alpha=0.5)
#    plt.plot(np.arange(N)+N/2, KBDStopWindow(data, M/2, N/2), 'b')
#    plt.fill_between(np.arange(N)+N/2, KBDStopWindow(data, M/2, N/2),0,color='b',alpha=0.5)
#    #spacing = N/4-M/4
#    plt.xticks(np.arange(len(data)*3/(2*128)+1)*128)
#    plt.xlim([0, 3*len(data)/2])
#    plt.title("Start and Stop Window Sequence")
#    plt.xlabel("Samples")
#    plt.ylabel("Amplitude")
#    plt.show()

    #############################
#    plt.figure()
#    plt.grid(True)
#    plt.hold(True)
#    for i in range(N/M):
#      plt.plot(np.arange(M)+spacing+i*M/2, KBDWindow(data[:M]), colors[i%len(colors)])
#      plt.fill_between(np.arange(M)+spacing+i*M/2, KBDWindow(data[:M]),0,color=colors[i%len(colors)],alpha=0.5)
#    for i in range(N/M):
#      plt.plot(np.arange(M)+spacing+N/2+i*M/2, KBDWindow(data[:M]), colors[i%len(colors)])
#      plt.fill_between(np.arange(M)+spacing+N/2+i*M/2, KBDWindow(data[:M]),0,color=colors[i%len(colors)],alpha=0.5)
#    plt.xticks(np.arange(len(data)*3/(2*128)+1)*128)
#    plt.xlim([0, 3*len(data)/2])
#    plt.title("Two sets of short windows")
#    plt.xlabel("Samples")
#    plt.ylabel("Amplitude")
#    plt.show()
