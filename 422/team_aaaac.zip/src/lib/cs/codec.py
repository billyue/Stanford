"""
codec.py -- The actual encode/decode functions for the perceptual audio codec

-----------------------------------------------------------------------
 2009 Marina Bosi & Richard E. Goldberg -- All rights reserved
-----------------------------------------------------------------------
"""

import numpy as np  # used for arrays

# current window used for MDCT
from window import KBDWindow, KBDStartWindow, KBDStopWindow
# fast MDCT implementation (uses numpy FFT)
from mdct import MDCT, IMDCT
# using vectorized versions (to use normal versions,
# uncomment lines 18,67 below defining vMantissa and vDequantize)
#from ..vendor.quantize import vMantissa, Mantissa as VendorMantissa
from quantize import ScaleFactor, vDequantize, vMantissa

# calculates SMRs for each scale factor band
from .psychoac import CalcStereoMaskThresh, EncodeMS, DecodeMS, CalcStereoDecision
# allocates bits to scale factor bands given SMRs
from .bitalloc import BitAlloc
#from .bitalloc import BitAllocUniform as BitAlloc
#from .bitalloc import BitAllocConstSNR as BitAlloc

from huffman import EncodeHuffman, DecodeHuffman
from window import WindowType

def Decode(scaleFactor, bitAlloc, mantissa, overallScaleFactor, codingParams):
    """Reconstitutes a two-channel block of encoded data into a block of
    signed-fraction data based on the parameters in a PACFile object"""

    mdctLine = []

    for iCh in range(codingParams.nChannels):
        #rescaleLevel = 1. * (1 << overallScaleFactor[iCh])
        if codingParams.blockType==WindowType.Short:
            sfBands = codingParams.sfBandsShort
            halfN = codingParams.nMDCTLinesShort
        else:
            sfBands = codingParams.sfBands
            halfN = codingParams.nMDCTLines

        # reconstitute the first halfN MDCT lines of this channel from the
        # stored data
        mdctLine.append(np.zeros(halfN, dtype=np.float64))
        iMant = 0
        for iBand in range(sfBands.nBands):
            nLines = sfBands.nLines[iBand]
            if bitAlloc[iCh][iBand]:
                mdctLine[iCh][iMant:(iMant+nLines)] = vDequantize(
                    scaleFactor[iCh][iBand],
                    mantissa[iCh][iMant:(iMant+nLines)],
                    codingParams.nScaleBits,
                    bitAlloc[iCh][iBand]
                )
            iMant += nLines
        #mdctLine[iCh] /= rescaleLevel  # put overall gain back to original level

    # Stereo decode from M/S to L/R based on sendMS (band by band information)
    mdctLine = DecodeMS( mdctLine, sfBands, codingParams.sendMS )

    # put overall gain back to original level
    for iCh in range(codingParams.nChannels):
        rescaleLevel = 1. * (1 << overallScaleFactor[iCh])
        mdctLine[iCh] /= rescaleLevel  

    # IMDCT and window the data for this channel
    # takes in halfN MDCT coeffs
    #decodedLeft = KBDWindow(IMDCT(mdctLine[0], halfN, halfN))
    #decodedRight = KBDWindow(IMDCT(mdctLine[1], halfN, halfN))

    if (codingParams.blockType==WindowType.Short) or (codingParams.blockType==WindowType.Long):
        decodedLeft  = KBDWindow(IMDCT(mdctLine[0], halfN, halfN))
        decodedRight = KBDWindow(IMDCT(mdctLine[1], halfN, halfN))
    elif codingParams.blockType==WindowType.Start:
        decodedLeft  = KBDStartWindow(IMDCT(mdctLine[0], halfN, halfN), codingParams.nMDCTLines, codingParams.nMDCTLinesShort )
        decodedRight = KBDStartWindow(IMDCT(mdctLine[1], halfN, halfN), codingParams.nMDCTLines, codingParams.nMDCTLinesShort )
    elif codingParams.blockType==WindowType.Stop:
        decodedLeft  = KBDStopWindow(IMDCT(mdctLine[0], halfN, halfN), codingParams.nMDCTLinesShort, codingParams.nMDCTLines )
        decodedRight = KBDStopWindow(IMDCT(mdctLine[1], halfN, halfN), codingParams.nMDCTLinesShort, codingParams.nMDCTLines )
    
    #decodedLeft = DecodeSingleChannel(scaleFactor[0], bitAlloc[0], mantissa[0], overallScaleFactor[0], codingParams)
    #decodedRight = DecodeSingleChannel(scaleFactor[1], bitAlloc[1], mantissa[1], overallScaleFactor[1], codingParams)

    return [decodedLeft, decodedRight]


def DecodeSingleChannel(scaleFactor, bitAlloc, mantissa, overallScaleFactor, codingParams):
    """Reconstitutes a single-channel block of encoded data into a block of
    signed-fraction data based on the parameters in a PACFile object"""

    rescaleLevel = 1. * (1 << overallScaleFactor)
    if codingParams.blockType==WindowType.Short:
        sfBands = codingParams.sfBandsShort
        halfN = codingParams.nMDCTLinesShort
    else:
        sfBands = codingParams.sfBands
        halfN = codingParams.nMDCTLines
    # reconstitute the first halfN MDCT lines of each channel from the
    # stored data
    mdctLine = np.zeros(halfN, dtype=np.float64)
    iMant = 0
    for iBand in range(sfBands.nBands):
        nLines = sfBands.nLines[iBand]
        if bitAlloc[iBand]:
            mdctLine[iMant:(iMant+nLines)] = vDequantize(
                scaleFactor[iBand],
                mantissa[iMant:(iMant+nLines)],
                codingParams.nScaleBits,
                bitAlloc[iBand]
            )
        iMant += nLines
    mdctLine /= rescaleLevel  # put overall gain back to original level
    
    # IMDCT and window the data for this channel
    # takes in halfN MDCT coeffs
    if (codingParams.blockType==WindowType.Short) or (codingParams.blockType==WindowType.Long):
        data = KBDWindow(IMDCT(mdctLine, halfN, halfN))
    elif codingParams.blockType==WindowType.Start:
        data = KBDStartWindow(IMDCT(mdctLine, halfN, halfN), codingParams.nMDCTLines, codingParams.nMDCTLinesShort )
    elif codingParams.blockType==WindowType.Stop:
        data = KBDStopWindow(IMDCT(mdctLine, halfN, halfN), codingParams.nMDCTLinesShort, codingParams.nMDCTLines )

    # end loop over channels, return reconstituted time sample
    # (pre-overlap-and-add)
    return data


def Encode(data, codingParams):
    """Encodes a multi-channel block of signed-fraction data based on the
    parameters in a PACFile object"""

    # 1 isn't an allowed bit allocation so n size bits counts up to 2^n
    maxMantBits = (1 << codingParams.nMantSizeBits)
    # to make sure we don't ever overflow mantissa holders
    if maxMantBits > 16:
        maxMantBits = 16

    if codingParams.blockType==WindowType.Short:
        sfBands = codingParams.sfBandsShort
        halfN = codingParams.nMDCTLinesShort
        isShortWindow = True
	nMantSizeBits = codingParams.nMantSizeBitsShort
	nScaleBits = codingParams.nScaleBitsShort
    else:
        sfBands = codingParams.sfBands
        halfN = codingParams.nMDCTLines
        isShortWindow = False
	nMantSizeBits = codingParams.nMantSizeBits
	nScaleBits = codingParams.nScaleBits

    # mantissa bit budget for this block of halfN MDCT mantissas
    # this is overall target bit rate
    bitBudget = codingParams.targetBitsPerSample * halfN
    # less scale factor bits (including overall scale factor)
    bitBudget -= nScaleBits*(sfBands.nBands + 1)
    # less mantissa bit allocation bits
    bitBudget -= nMantSizeBits*sfBands.nBands

    # we will be calculating the bit allocation for both channels together
    bitBudget *= 2

    # Add leftover bits from last time
    bitBudget += codingParams.priorUnusedBits

    # And truncating to an integer here for simplicity in calculations below
    bitBudget = int(bitBudget)

    # window time domain data for FFT and compute MDCT per channel
    timeSamples = []
    mdctTimeSamples = []
    mdctLines = []
    maxLine = []
    overallScale = []
    for iCh in range(codingParams.nChannels):
        timeSamples.append(data[iCh])
        if (codingParams.blockType==WindowType.Short) or (codingParams.blockType==WindowType.Long):
            mdctTimeSamples.append(KBDWindow(data[iCh]))
        elif codingParams.blockType==WindowType.Start:
            mdctTimeSamples.append(KBDStartWindow(data[iCh], codingParams.nMDCTLines, codingParams.nMDCTLinesShort))
        elif codingParams.blockType==WindowType.Stop:
            mdctTimeSamples.append(KBDStopWindow(data[iCh], codingParams.nMDCTLinesShort, codingParams.nMDCTLines))

        mdctLines.append(MDCT(mdctTimeSamples[iCh], halfN, halfN)[:halfN])

        # compute overall scale factor for this block and boost mdctLines
        # using it
        maxLine.append(np.max(np.abs(mdctLines[iCh])))
        # leading zeroes don't depend on nMantBits
        overallScale.append(ScaleFactor(maxLine[iCh], nScaleBits))
        mdctLines[iCh] *= (1 << overallScale[iCh])

    # Stereo Coding: M/S or L/R decisions
    sendMS = CalcStereoDecision( mdctLines, sfBands )
    
    # compute SMRs for each channel
    SMRs = CalcStereoMaskThresh(
        timeSamples,
        mdctLines,
        overallScale,
        codingParams.sampleRate,
        sfBands,
        sendMS,
        isShortWindow
    )
   
    # Stereo Coding: Encode as L/R or M/S based on sendMS
    mdctLines = EncodeMS( mdctLines, sfBands, sendMS )

    # perform bit allocation per channel using SMR
    bitAlloc = BitAlloc(
        bitBudget,
        maxMantBits,
        sfBands.nBands,
        sfBands.nLines,
        SMRs
    )

    # Amount of bits used for both channels combined
    usedBits = (
        np.sum(sfBands.nLines * bitAlloc[0])
        + np.sum(sfBands.nLines * bitAlloc[1])
    )

    # Amount of bits left over for both channels
    codingParams.priorUnusedBits = np.maximum(bitBudget - usedBits, 0)

    # compute scale factors and mantissas per channel
    scaleFactor = []
    mantissa = []

    # loop over channels and separately encode each one
    for iCh in range(codingParams.nChannels):
        (s, m) = QuantizeSingleChannel(
            data[iCh],
            codingParams,
            bitAlloc[iCh],
            mdctLines[iCh]
        )
        scaleFactor.append(s)
        mantissa.append(m)

    # return results bundled over channels
    return (scaleFactor, bitAlloc, mantissa, overallScale, sendMS)


def QuantizeSingleChannel(data, codingParams, bitAlloc, mdctLines):
    """Quantizes a single-channel block of signed-fraction data based on the
    bit allocation"""
    
    if codingParams.blockType==WindowType.Short:
        sfBands = codingParams.sfBandsShort
        halfN = codingParams.nMDCTLinesShort
    else:
        sfBands = codingParams.sfBands
        halfN = codingParams.nMDCTLines

    nScaleBits = codingParams.nScaleBits

    # given the bit allocations, quantize the mdct lines in each band
    scaleFactor = np.empty(sfBands.nBands, dtype=np.int32)
    nMant = halfN
    for iBand in range(sfBands.nBands):
        # account for mantissas not being transmitted
        if not bitAlloc[iBand]:
            nMant -= sfBands.nLines[iBand]
    mantissa = np.empty(nMant, dtype=np.int32)
    iMant = 0
    for iBand in range(sfBands.nBands):
        lowLine = sfBands.lowerLine[iBand]
        # extra value is because slices don't include last value
        highLine = sfBands.upperLine[iBand] + 1
        nLines = sfBands.nLines[iBand]
        if len(mdctLines[lowLine:highLine])!=0:
            scaleLine = np.max(np.abs(mdctLines[lowLine:highLine]))
        else:
            scaleLine = 0
        scaleFactor[iBand] = ScaleFactor(
            scaleLine,
            nScaleBits,
            bitAlloc[iBand]
        )
        if bitAlloc[iBand]:
            mantissa[iMant:iMant+nLines] = vMantissa(
                mdctLines[lowLine:highLine],
                scaleFactor[iBand],
                nScaleBits,
                bitAlloc[iBand]
            )
            iMant += nLines
    # end of loop over scale factor bands

    # return results
    return (scaleFactor, mantissa)
