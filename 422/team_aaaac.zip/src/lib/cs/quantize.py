###
#   @file       quantize.py
#
#               Routines to quantize and dequantize floating point data
#               (expected to be between -1.0 and 1.0)
#
#   @author     Colin Sullivan <colin [at] colin-sullivan.net>
#
#               Copyright (c) 2013 Colin Sullivan
#               Licensed under the MIT license.
###

import numpy as np


def QuantizeUniform(aNum, nBits):
    """Uniformly quantize signed fraction aNum with nBits.

    :aNum: The float (type(numpy.float64) on my machine) value to quantize.
    :nBits: The number of bits to quantize to.
    :returns: quantized code stored in an unsigned integer type(int).
    """

    #Notes:
    #The overload level of the quantizer should be 1.0

    absNum = abs(aNum)
    absCode = None
    if absNum >= 1:
        absCode = (2 ** (nBits - 1)) - 1
    else:
        absCode = int(((2 ** nBits - 1) * absNum + 1) / 2)

    if aNum < 0:
        absCode += (2 ** (nBits - 1))
    return absCode


def DequantizeUniform(aQuantizedNum, nBits):
    """Uniformly dequantizes nBits-long number aQuantizedNum into a signed
    fraction"""

    # To get the sign of the quantized number, compare with this bitmask
    # (1000 for 4-bit)
    signBitMask = 2 ** (nBits - 1)
    signBit = np.bitwise_and(signBitMask, aQuantizedNum)
    sign = None
    if signBit == signBitMask:
        sign = -1
    else:
        sign = 1

    # To get the absolute value of the code, compare with this bitmask (0111
    # for 4-bit)
    codeBitMask = signBitMask - 1
    absCode = np.bitwise_and(codeBitMask, aQuantizedNum)

    # 2.|code| / (2^R - 1)
    # float conversion at this particular point is necessary.
    absNumber = float(np.left_shift(absCode, 1)) / (2 ** nBits - 1)

    number = (sign * absNumber)

    return number


def vQuantizeUniform(aNumVec, nBits):
    """Uniformly quantize vector of floats to quantized codes stored as
    unsigned integers.
    :aNumVec: Vector of floats to quantize.
    :nBits: Bit-depth to quantize to.
    :returns: Vector of quantized values.
    """

    # Vector of the absolute values of the input vector
    absNums = np.absolute(aNumVec)
    # Vector of booleans denoting if each element is a decimal or not
    isDecimal = np.less(absNums, 1.0)
    isNotDecimal = np.logical_not(isDecimal)

    # Vector of booleans describing if each element is negative
    isNegative = np.less(aNumVec, 0.0)

    absCodeIfNotDecimal = (2 ** (nBits - 1)) - 1
    # converts boolean array ([True, False, False]) into integers ([1, 0, 0]),
    # then element-wise multiply with `absCodeIfNotDecimal` above, ([x, 0, 0])
    absCodesNonDecimals = isNotDecimal.astype(np.uint) * absCodeIfNotDecimal

    # Quantize decimals
    absCodesDecimals = isDecimal.astype(np.uint) * absNums
    absCodesDecimals = (
        absCodesDecimals * (2 ** nBits - 1) + 1
    ).astype(np.uint)/2

    # combine quantized decimals and non-decimals
    absCodes = absCodesNonDecimals + absCodesDecimals

    # create sign bits
    signMask = (2 ** (nBits - 1))
    signs = (isNegative.astype(np.uint) * signMask).astype(np.uint)
    # combine sign bits with absolute values to create codes
    codes = signs + absCodes

    return codes


def vDequantizeUniform(aQuantizedNumVec, nBits):
    """Uniformly dequantizes vector of nBits-long numbers aQuantizedNumVec
    into vector of floats.

    :aQuantizedNumVec: Vector of quantized codes stored as unsigned ints.
    :nBits: Bit-depth to quantize to.
    :return: Vector of de-quantized floats.
    """

    signBitMask = 2 ** (nBits - 1)
    signBitsVec = np.bitwise_and(signBitMask, aQuantizedNumVec)
    isNegativeVec = np.equal(signBitsVec, signBitMask)
    isNotNegativeVec = np.logical_not(isNegativeVec)
    signsVec = (
        (isNegativeVec.astype(int) * -1.0)
        + (isNotNegativeVec.astype(int) * 1.0)
    )

    absCodeBitMask = signBitMask - 1
    absCodesVec = np.bitwise_and(absCodeBitMask, aQuantizedNumVec)
    absNumbersVec = (
        np.left_shift(absCodesVec, 1).astype(float) / (2 ** nBits - 1)
    )

    numbersVec = signsVec * absNumbersVec

    return numbersVec


def ScaleFactor(aNum, nScaleBits=3, nMantBits=5):
    """Return the floating-point scale factor for a signed fraction aNum given
    nScaleBits scale bits and nMantBits mantissa bits.

    :aNum: The float number to calculate the scale bits of
    :nScaleBits: Number of bits allocated for the scale
    :nMantBits: Number of bits allocated for the mantissa
    :returns: The scale factor (number of leading zeros) represented as an
    unsigned integer
    """

    scaleMask = 2 ** nScaleBits - 1
    R = scaleMask + nMantBits
    code = QuantizeUniform(aNum, R)

    # Count number of leading zeros in |code|
    numLeadingZeroes = 0
    i = R - 2
    while i >= 0:
        leadingZeroMask = 2 ** i
        if np.bitwise_xor(code, leadingZeroMask) == (leadingZeroMask + code):
            numLeadingZeroes += 1
        else:
            break
        i -= 1

    scale = scaleMask
    if numLeadingZeroes < scaleMask:
        scale = numLeadingZeroes

    return scale


def MantissaFP(aNum, scale, nScaleBits=3, nMantBits=5):
    """Return the floating-point mantissa for a float.

    :aNum: The number to calculate the mantissa of
    :scale: The scale bits calcualted for `aNum`
    :nScaleBits: The number of scale bits being used
    :nMantBits: The number of mantissa bits being used
    :returns: The mantissa bits encoded in an unsigned int.
    """

    maxScale = 2 ** nScaleBits - 1
    R = maxScale + nMantBits
    code = QuantizeUniform(aNum, R)

    # To get the sign of the quantized number, compare with this bitmask
    # (1000 for 4-bit)
    signBitMask = 2 ** (R - 1)
    signBit = np.bitwise_and(signBitMask, code)

    # To get the absolute value of the code, compare with this bitmask (0111
    # for 4-bit)
    codeBitMask = signBitMask - 1
    absCode = np.bitwise_and(codeBitMask, code)

    # initialize mantissa, set first mantissa bit equal to the sign bit
    mantissa = np.right_shift(signBit, R - nMantBits)

    # Create mask of a length of nMantBits - 1 to pull the bits out of |code|
    mantissaDigitsMask = (2 ** nMantBits) - 1

    if scale == maxScale:

        mantissaDigits = np.bitwise_and(mantissaDigitsMask, absCode)

    else:

        # ignore sign bit
        mantissaDigitsMask = np.right_shift(
            mantissaDigitsMask,
            1
        )

        # extract mantissa digits
        mantissaDigits = np.bitwise_and(mantissaDigitsMask, absCode)

        # Move in place to the right of the sign bit
        #mantissaDigits = np.right_shift(mantissaDigits, 1)

    # set the remaining mantissa bits equal to the extracted significant
    # code bits
    mantissa += mantissaDigits

    return int(mantissa)


def DequantizeFP(scale, mantissa, nScaleBits=3, nMantBits=5):
    """Returns a float for a quantized code based on a floating-point
    quantization scheme.

    :scale: The scale of the quantized code.
    :mantissa: The mantissa of the quantized code.
    :nScaleBits: Amount of bits allocated for the scale.
    :nMantBits: Amount of bits allocated for the mantissa.
    """

    maxScale = 2 ** nScaleBits - 1
    R = maxScale + nMantBits

    # Extract sign bit from mantissa
    signBitMask = 2 ** (nMantBits - 1)
    signBit = np.bitwise_and(signBitMask, mantissa)

    # Put sign bit in left-most bit of code
    code = np.left_shift(signBit, R - nMantBits)

    # extract remaining mantissa bits
    mantissaBitsMask = 2 ** (nMantBits - 1) - 1
    mantissaBits = np.bitwise_and(mantissaBitsMask, mantissa)

    if scale == maxScale:
        # Add mantissa bits to code to the right of the leading zeros
        code += np.left_shift(mantissaBits, R - scale - nMantBits)
    else:
        # Add 1 after leading zeros
        code += 2 ** (R - scale - 2)

        # Add remaining mantissa bits after 1
        code += np.left_shift(mantissaBits, R - scale - 1 - nMantBits)

    if scale < maxScale - 1:
        # quantize least-significant bits to middle value
        code += 2 ** (R - scale - 2 - nMantBits)

    return DequantizeUniform(int(code), R)


def Mantissa(aNum, scale, nScaleBits=3, nMantBits=5):
    """Return the block floating-point mantissa

    :aNum: The float value to quantize
    :scale: The scale bits stored as an unsigned int
    :nScaleBits: The number of scale bits
    :nMantBits: The number of mantissa bits
    """

    maxScale = 2 ** nScaleBits - 1
    R = maxScale + nMantBits
    code = QuantizeUniform(aNum, R)

    # To get the sign of the quantized number, compare with this bitmask
    # (1000 for 4-bit)
    signBitMask = 2 ** (R - 1)
    signBit = np.bitwise_and(signBitMask, code)

    # To get the absolute value of the code, compare with this bitmask (0111
    # for 4-bit)
    codeBitMask = signBitMask - 1
    absCode = np.bitwise_and(codeBitMask, code)

    # initialize mantissa, set first mantissa bit equal to the sign bit
    mantissa = np.right_shift(signBit, R - nMantBits)

    # Create mask of a length of nMantBits - 1 to pull the bits out of |code|
    mantissaDigitsMask = (2 ** (nMantBits - 1)) - 1

    if scale == maxScale:

        # move left to mask bits following the maxScale leading zeros
        #mantissaDigitsMask = np.left_shift(mantissaDigitsMask, maxScale)
        mantissaDigits = np.bitwise_and(mantissaDigitsMask, absCode)

    else:

        # mask out values just past leading zeros
        mantissaDigitsMask = np.left_shift(
            mantissaDigitsMask,
            R - nMantBits - scale
        )

        # extract mantissa digits
        mantissaDigits = np.bitwise_and(mantissaDigitsMask, absCode)

        # Move in place to the right of the sign bit
        mantissaDigits = np.right_shift(mantissaDigits, R - nMantBits - scale)

    # set the remaining mantissa bits equal to the extracted significant
    # code bits
    mantissa += mantissaDigits

    return int(mantissa)


def Dequantize(scale, mantissa, nScaleBits=3, nMantBits=5):
    """Returns a float from a quantized block floating-point code.

    :scale: The group scale bits
    :mantissa: The mantissa of this value
    :nScaleBits: The number of bits used for scale
    :nMantBits: The number bits used for mantissa
    """

    maxScale = 2 ** nScaleBits - 1
    R = maxScale + nMantBits

    # Extract sign bit from mantissa
    signBitMask = 2 ** (nMantBits - 1)
    signBit = np.bitwise_and(signBitMask, mantissa)

    # Put sign bit in left-most bit of code
    code = np.left_shift(signBit, R - nMantBits)

    # extract remaining mantissa bits
    mantissaBitsMask = 2 ** (nMantBits - 1) - 1
    mantissaBits = np.bitwise_and(mantissaBitsMask, mantissa)

    if scale == maxScale:
        # Add mantissa bits to code to the right of the leading zeros
        code += np.left_shift(mantissaBits, R - nMantBits - scale)
    else:
        # Add 1 after leading zeros
        #code += 2 ** (R - scale - 2)

        # Add remaining mantissa bits after 1
        code += np.left_shift(mantissaBits, R - scale - nMantBits)

    if scale < (maxScale - 1) and (mantissaBits != 0):
        # quantize least-significant bits to middle value
        code += 2 ** (R - scale - 1 - nMantBits)

    return DequantizeUniform(int(code), R)


def vMantissa(aNumVec, scale, nScaleBits=3, nMantBits=5):
    """Return a vector of block floating-point mantissas for a vector of float
    values to quantize.

    :aNumVec: The vector of values to quantize
    :scale: The scale bits used for the group
    :nScaleBits: Amount of bits used in scale
    :nMantBits: Amount of bits used for mantissa
    """

    maxScale = 2 ** nScaleBits - 1
    R = maxScale + nMantBits
    codesVec = vQuantizeUniform(aNumVec, R)

    # Extract sign bit of each code
    signBitMask = 2 ** (R - 1)
    signBitsVec = np.bitwise_and(signBitMask, codesVec)

    # Extract absolute value of each code
    codeBitMask = signBitMask - 1
    absCodesVec = np.bitwise_and(codeBitMask, codesVec)

    # We will have a mantissa for each number
    mantissasVec = np.zeros(len(aNumVec), dtype=np.uint)

    # Initialize mantissa, set the first bit to the sign bit of each number
    mantissasVec += np.right_shift(signBitsVec, R - nMantBits)

    # Create a mask of length nMantBits - 1 to pull the significant
    # bits out of |code|
    mantissaDigitsMask = (2 ** (nMantBits - 1)) - 1

    if scale == maxScale:
        # move mask to the left above the most significant bits following
        # the leading zeros
        #mantissaDigitsMask = np.left_shift(mantissaDigitsMask, maxScale)
        # Extract significant digits
        mantissaDigitsVec = np.bitwise_and(mantissaDigitsMask, absCodesVec)

    else:

        # move mask to the left above the bits following the `scale` leading
        # zeroes
        mantissaDigitsMask = np.left_shift(
            mantissaDigitsMask,
            R - nMantBits - scale
        )

        # extract mantissa digits
        mantissaDigitsVec = np.bitwise_and(mantissaDigitsMask, absCodesVec)

        # move in place to the right side of the sign bit
        mantissaDigitsVec = np.right_shift(
            mantissaDigitsVec,
            R - nMantBits - scale
        )

    # set the significant bits on each mantissa
    mantissasVec += mantissaDigitsVec

    return mantissasVec


def vDequantize(scale, mantissaVec, nScaleBits=3, nMantBits=5):
    """Returns a vector of dequantized float values for a vector of block
    floating-point quantized codes.

    :scale: The scale factor for the group
    :mantissaVec: The vector of mantissa values
    :nScaleBits: The amount of bits used for the scale value
    :nMantBits: The amount of bits used for the mantissa
    """

    maxScale = 2 ** nScaleBits - 1
    R = maxScale + nMantBits

    # Extract sign bit from each mantissa
    signBitMask = 2 ** (nMantBits - 1)
    signBitsVec = np.bitwise_and(signBitMask, mantissaVec)

    # create blank codes
    codesVec = np.zeros(len(mantissaVec), dtype=int)

    # Put sign bits in left-most bit of each code
    codesVec += np.left_shift(signBitsVec, R - nMantBits)

    # Extract remaining mantissa bits
    mantissaBitsMask = 2 ** (nMantBits - 1) - 1
    mantissaBitsVec = np.bitwise_and(mantissaBitsMask, mantissaVec)

    if scale == maxScale:
        # add mantissa bits to code to the right of the leading zeros
        codesVec += np.left_shift(mantissaBitsVec, R - nMantBits - scale)

    else:

        # Add remaining mantissa bits
        codesVec += np.left_shift(mantissaBitsVec, R - scale - nMantBits)

    if scale < (maxScale - 1):
        # Quantize least significant bits of each non-zero code to
        # the middle value
        nonZeroCodesVec = np.not_equal(mantissaBitsVec, 0).astype(np.uint)
        codesVec += nonZeroCodesVec * (
            2 ** (R - scale - 1 - nMantBits)
        )

    return vDequantizeUniform(codesVec, R)
