#!/usr/bin/python
"""
_____________________________________
___    |__    |__    |__    |_  ____/
__  /| |_  /| |_  /| |_  /| |  /
_  ___ |  ___ |  ___ |  ___ / /___
/_/  |_/_/  |_/_/  |_/_/  |_\____/


All-American-Advanced-Audio-Codec

transient.py

Detects transients in a given block of stereo audio samples.

Tim O'Brien

For detecting transients.
"""
import numpy as np
from numpy import hstack, array
from window import HanningWindow

def first_difference(data):
    """
    Takes an array of data and returns a the first order difference
    y(n) = x(n) - x(n-1)
    """
    return data - hstack([ array([0.0]), data[0:len(data)-1] ])

def highpass(data):
    """
    Takes an array of data and returns a high-passed version.
    Uses simplest high pass filter: y(n) = x(n) - x(n-1)
    """
    highpass = data - hstack([ array([0.0]), data[0:len(data)-1] ])
    #highpass = highpass - hstack([ array([0.0]), highpass[0:len(data)-1] ])
    return highpass

def highpassA(data):
    """
    Takes stereo data and returns a high-passed version.
    """
    highpassA = np.zeros_like(data)
    for iCh in range(len(data)):
        highpassA[iCh] = highpass(data[iCh])
    return highpassA

def lowpass(data):
    """
    Takes an array of data and returns a high-passed version.
    Uses simplest high pass filter: y(n) = x(n) - x(n-1)
    """
    lowpass = data + hstack([ array([0.0]), data[0:len(data)-1] ])
    #lowpass = lowpass + hstack([ array([0.0]), lowpass[0:len(data)-1] ])
    return lowpass

def lowpassA(data):
    """
    Takes stereo data and returns a low-passed version.
    """
    lowpassA = np.zeros_like(data)
    for iCh in range(len(data)):
        lowpassA[iCh] = lowpass(data[iCh])
    return lowpassA

def detectTransient(data, codingParams, thresh = 0.03, threshdiff = 1.1 ):
    """
    Detects a transient in a block of stereo audio data.

    :data: a block of stereo audio samples in a 2D array.
    :codingParams: the PACFile/PCMFile codingParams object.
    :thresh: tuned threshold for average change in log energy over the block.
    :threshdiff: threshold for the change in the above mentioned quantity from the previous block.
    """
    nCh = len(data)
    N = len(data[0])
    dE = np.zeros_like(data)

    highPass = highpassA(data) # Highpass the input audio data

    # Compute envelope follower for log of local energy, E,
    # then take the first difference (i.e. time derivative)
    E = np.zeros_like(data)
    for iCh in range(len(data)):
        E[iCh] = HanningWindow(np.power(highPass[iCh],2) / float(len(highPass[iCh])))
        E[iCh] = lowpass(E[iCh])
        E[iCh] = np.log10( np.maximum(E[iCh], 0.000001) )
        dE[iCh] = first_difference(E[iCh])
        dE[iCh] = np.maximum(dE[iCh],0.0)

    # take the average over the block
    avg = np.sum(dE)/float(nCh*N)

    # it's a transient if avg is greater than the threshold value
    if avg>thresh and avg/max(codingParams.lastTrans,0.00001)>threshdiff:
        trans = 1
    else:
        trans = 0

    codingParams.lastTrans = avg
    return trans

if __name__ == "__main__":
    print "See ../../TestTransient.py for testing and demo functionality."

