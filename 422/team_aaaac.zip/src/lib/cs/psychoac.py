import numpy as np
#import matplotlib.pyplot as plt
#from window import *

from .window import HanningWindow, SineWindow
from .normalization import SPL_dft, SPL_MDCT


def SPL(intensity):
    """Returns the SPL corresponding to intensity (in units where 1 implies
    96dB)

    :intensity: Intensity value (scalar or np.array)
    :returns: SPL value (scalar or np.array)
    """
    if type(intensity) is np.float64:
        if intensity < 0.0:
            raise Exception("value is negative in SPL function in psychoac.py")
    else:
        lessThanZero = intensity < 0
        if len(intensity[lessThanZero]) > 0:
            print intensity[lessThanZero]
            raise Exception("value is negative in SPL function in psychoac.py - vector")
    spl = 96.0 + (10.0 * np.log10(intensity))
    return np.maximum(spl, -30.0)


def Intensity(spl):
    """Returns the intensity (in units of the reference intensity level) for
    SPL spl.

    :spl: SPL value (scalar or np.array)
    :returns: Intensity value (scalar or np.array)
    """
    intensity = np.power(10.0, ((spl - 96.0) / 10.0))
    return np.float64(intensity)


def Thresh(f):
    """Returns the threshold in quiet measured in SPL at frequency f
    (in Hz).

    :f: frequency in Hz (scalar or np.array)
    :returns: Threshold in dB (scalar or np.array)
    """

    # Minimum frequency to consider is 10 Hz
    f = np.maximum(f, 10.0)

    fKhz = f / 1000.0

    afdB = (
        3.64 * np.power(fKhz, -0.8)
        - 6.5 * np.exp(-0.6 * np.power((fKhz - 3.3), 2.0))
        + np.power(10.0, -3.0) * np.power(fKhz, 4.0)
    )

    return np.float64(afdB)


def Bark(f):
    """Returns the bark-scale frequency for input frequency f (in Hz)

    :f: Frequency in Hz  (scalar or np.array)
    :returns: value on the bark scale (scalar or np.array)
    """
    fKhz = f / 1000.0

    zBark = (
        13 * np.arctan(0.76 * fKhz)
        + 3.5 * np.arctan((fKhz / 7.5) ** 2)
    )
    return zBark


class Masker:
    """
    a Masker whose masking curve drops linearly in Bark beyond 0.5 Bark
    from the masker frequency
    """

    def __init__(self, f, spl, isTonal=True, isMLD=False, isShortWindow=False):
        """
        initialized with the frequency and SPL of a masker and whether or not
        it is Tonal
        """

        self.f = f
        self.z = Bark(self.f)
        self.spl = spl
        self.isTonal = isTonal
        self.isMLD = isMLD
	self.isShortWindow = isShortWindow

        pass

    def IntensityAtFreq(self, freq):
        """The intensity of this masker at frequency freq"""
        return 0

    def IntensityAtBark(self, z):
        """The intensity of this masker at Bark location z"""

        dz = z - self.z

        spl = self.spl

        if dz < -0.5:
            spl += -27.0 * (np.absolute(dz) - 0.5)
        elif dz > 0.5:
            spl += (
                -27.0 + 0.37 * np.maximum(self.spl - 40.0, 0.0)
            ) * (np.absolute(dz) - 0.5)

        if not self.isMLD:
            if self.isTonal:
		if not self.isShortWindow:
                	spl -= 14.5
		else:
			spl -= 18.0
            else:
		if not self.isShortWindow:
                	spl -= 5.5
		else:
			spl -= 8.5

        intensity = Intensity(spl)

        return np.float64(intensity)

    def vIntensityAtBark(self, zVec):
        """The intensity of this masker at vector of Bark locations zVec"""

        dzVec = zVec - self.z

        # elements that are on plateu of spreading function will remain at
        # the spl of the masker
        splVec = np.ones(len(dzVec)) * self.spl

        # on upward slope
        onUpwardVec = np.greater(dzVec, 0.5).astype(int)

        # Spls for the dzs on the upward slope of the spreading function,
        # only the elements with a 1 in `onUpwardVec` are relevant
        onUpwardSplVec = onUpwardVec * (
            (-27.0 + 0.37 * np.maximum(self.spl - 40.0, 0.0))
            * (np.absolute(dzVec) - 0.5)
        )

        # on downward slope
        onDownwardVec = np.less(dzVec, -0.5).astype(int)

        onDownwardSplVec = onDownwardVec * (
            -27.0 * (np.absolute(dzVec) - 0.5)
        )

        # incorporate upward and downward
        splVec += onUpwardSplVec + onDownwardSplVec

        if not self.isMLD:
            if self.isTonal:
		if not self.isShortWindow:
                	splVec -= 14.5
		else:
			splVec -= 18.0
            else:
		if not self.isShortWindow:
                	splVec -= 5.5
		else:
			splVec -= 8.5

        intensityVec = Intensity(splVec)

        return intensityVec

# Default data for 25 scale factor bands based on the traditional 25 critical
# bands
cbFreqLimits = [
    100.0,
    200.0,
    300.0,
    400.0,
    510.0,
    630.0,
    770.0,
    920.0,
    1080.0,
    1270.0,
    1480.0,
    1720.0,
    2000.0,
    2320.0,
    2700.0,
    3150.0,
    3700.0,
    4400.0,
    5300.0,
    6400.0,
    7700.0,
    9500.0,
    12000.0,
    15500.0
]


def AssignMDCTLinesFromFreqLimits(nMDCTLines, fs, flimit=cbFreqLimits):
    """
    Assigns MDCT lines to scale factor bands for given sample rate and number
    of MDCT lines using predefined frequency band cutoffs passed as an array
    in flimit (in units of Hz). If flimit isn't passed it uses the traditional
    25 Zwicker & Fastl critical bands as scale factor bands.
    """

    # Frequencies of each MDCT bin
    binFreqs = ((np.arange(nMDCTLines) + 0.5) / nMDCTLines) * (0.5 * fs)

    # Number of bands we are assigning the above bins into
    numBands = len(flimit) + 1

    # The amount of MDCT lines in each scale factor band (initially 0)
    scaleFactorBandNumLines = np.zeros(numBands).astype(np.float64)

    # pointer to MDCT bin that is next to be assigned to a band
    nextBinIndex = 0

    # for each band limit, count bins that are less than the band limit
    for i in range(numBands - 1):
        bandLimit = flimit[i]
        while (nextBinIndex < len(binFreqs)
                and binFreqs[nextBinIndex] < bandLimit):
            scaleFactorBandNumLines[i] += 1.0
            nextBinIndex += 1.0

    # final critical band is remaining MDCT lines
    while(
	nextBinIndex < len(binFreqs)
	and np.sum(scaleFactorBandNumLines) < nMDCTLines
    ):
        scaleFactorBandNumLines[numBands - 1] += 1.0
        nextBinIndex += 1.0

    scaleFactorBandNumLines = np.trim_zeros(scaleFactorBandNumLines, 'b')

    scaleFactorBandNumLines = scaleFactorBandNumLines.tolist()

    for i in range(len(scaleFactorBandNumLines)):
        scaleFactorBandNumLines[i] = np.float64(scaleFactorBandNumLines[i])

    return scaleFactorBandNumLines


class ScaleFactorBands:
    """
    A set of scale factor bands (each of which will share a scale factor and a
    mantissa bit allocation) and associated MDCT line mappings.

    Instances know the number of bands nBands; the upper and lower limits for
    each band lowerLimit[i in range(nBands)], upperLimit[i in range(nBands)];
    and the number of lines in each band nLines[i in range(nBands)]
    """

    def __init__(self, nLines):
        """
        Assigns MDCT lines to scale factor bands based on a vector of the
        number of lines in each band
        """
        self.nLines = np.asarray(nLines).astype(np.uint16)
        self.nBands = len(nLines)

        # Calculate upper and lower limits for each band
        lowerLine = []
        upperLine = []
        prevBandLinesSum = 0.0
        for bandLine in self.nLines:

            # check for a zero
            if bandLine > 0:
                bandLowerIndex = prevBandLinesSum
                bandUpperIndex = prevBandLinesSum + bandLine - 1.0
                # check for small number of MDCT lines
                if bandUpperIndex == 0.0 - 1.0:
                    bandUpperIndex = prevBandLinesSum
                
                prevBandLinesSum = bandUpperIndex + 1.0
            else:
                bandLowerIndex = prevBandLinesSum
                bandUpperIndex = prevBandLinesSum

            lowerLine.append(bandLowerIndex)
            upperLine.append(bandUpperIndex)
                

        self.lowerLine = np.array(lowerLine).astype(np.uint16)
        self.upperLine = np.array(upperLine).astype(np.uint16)

### Stereo Coding ###
### L/R or M/S decision  ###
def CalcStereoDecision( MDCTdata, sfBands ):
    """
    Decides whether to transmit L/R or M/S
    :MDCTdata: MDCT frequency lines arranged as [leftData[], rightData[]]
    :sfBands: points to information about which MDCT frequency lines
    are in which scale factor band
    :returns: sendMS which is an array (length of sfBands.nBands)
    of values where a value of 0 means transmit LR and 1 means transmit MS
    """

    # WE CAN DO THIS WITH FFT TOO! Will that be better?


    sendMS = []

    # split up the MDCTdata into left and right channels
    MDCTleft = MDCTdata[0]
    MDCTright = MDCTdata[1]

    # calculate the decision
    for i in range(sfBands.nBands):
        bandLowerMDCTBinIndex = sfBands.lowerLine[i]
        bandUpperMDCTBinIndex = sfBands.upperLine[i]+1
        sqrMDCTleft = MDCTleft[
            bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
            ]**2
        sqrMDCTright = MDCTright[
            bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
            ]**2
        midInfo = np.sum(sqrMDCTleft + sqrMDCTright)
        sideInfo = np.sum(sqrMDCTleft - sqrMDCTright)
        if np.abs(sideInfo) < 0.8*np.abs(midInfo):
            sendMS.append(1)
        else:
            sendMS.append(0)

    
    #sqrMDCTleft = MDCTleft**2
    #sqrMDCTright = MDCTright**2
    #midInfo = np.sum(sqrMDCTleft + sqrMDCTright)
    #sideInfo = np.sum(sqrMDCTleft - sqrMDCTright)
    #if np.abs(sideInfo) < 0.8*np.abs(midInfo):
    #    sendMS = 1
    #else:
    #    sendMS = 0
        
    return sendMS

### Stereo Coding ###
### Encode if we are in M/S ###
def EncodeMS( MDCTdata, sfBands, sendMS ):
    """
    Gets called if we should transmit M/S information during encode process
    and encodes L/R into M/S
    :MDCTdata: left and right channels of MDCTdata in the form: [leftData[], rightData[]]
    :sfBands: points to information about which MDCT frequency lines
    are in which scale factor band
    :sendMS: an array (length of sfBands.nBands) of values where a value of 0 means transmit LR
    and 1 means transmit MS
    :returns: MDCTdata encoded as mid and side channels in the form: [midData[], sideData[]] 
    """

    leftData = MDCTdata[0]
    rightData = MDCTdata[1]

    stereoChan0 = np.zeros_like(leftData)
    stereoChan1 = np.zeros_like(rightData)

    # transmit L/R or M/S depending on decision on a band by band basis
    for i in range(sfBands.nBands):
        
        bandLowerMDCTBinIndex = sfBands.lowerLine[i]
        bandUpperMDCTBinIndex = sfBands.upperLine[i]+1
        leftBand = leftData[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ]
        rightBand = rightData[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ]
            
        if sendMS[i] == 1:
            # transmit M/S
            midData = (leftBand + rightBand) / 2.0#np.sqrt(2.0)
            sideData = (leftBand - rightBand) / 2.0#np.sqrt(2.0)
            stereoChan0[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ] = midData
            stereoChan1[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ] = sideData
        else:
            # transmit L/R
            stereoChan0[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ] = leftBand
            stereoChan1[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ] = rightBand
            
            
    return [stereoChan0, stereoChan1]      

    #midData = (leftData + rightData) / np.sqrt(2.0)
    #sideData = (leftData - rightData) / np.sqrt(2.0)

    #return [midData, sideData]


### Stereo Coding ###
### Decode if we are in M/S ###
def DecodeMS( MDCTdata, sfBands, sendMS ):
    """
    Gets called to decode stereo information into M/S or L/R
    :MDCTdata: two channels of MDCTdata in the form: [midData[], sideData[]]
    :sfBands: points to information about which MDCT frequency lines
    are in which scale factor band
    :sendMS: an array (length of sfBands.nBands) of values where a value of 0 means transmit LR
    and 1 means transmit MS
    :returns: MDCTdata encoded as left and right channels in the form: [leftData[], rightData[]] 
    """

    stereoChan0 = MDCTdata[0]
    stereoChan1 = MDCTdata[1]

    leftData = np.zeros_like(stereoChan0)
    rightData = np.zeros_like(stereoChan1)

    # decode according to information in sendMS on a band by band basis
    for i in range(sfBands.nBands):
        
        bandLowerMDCTBinIndex = sfBands.lowerLine[i]
        bandUpperMDCTBinIndex = sfBands.upperLine[i]+1
        chan0Band = stereoChan0[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ]
        chan1Band = stereoChan1[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ]
            
        if sendMS[i] == 1:
            # decode M/S
            midData = chan0Band
            sideData = chan1Band
            leftBand = (midData + sideData) #(np.sqrt(2.0)/2.0) * (midData + sideData)
            rightBand = (midData - sideData) #(np.sqrt(2.0)/2.0) * (midData - sideData)
            leftData[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ] = leftBand
            rightData[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ] = rightBand
        else:
            # decode L/R
            leftData[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ] = chan0Band
            rightData[
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
                ] = chan1Band

    return [leftData, rightData]    

    #leftData = (np.sqrt(2.0)/2.0) * (midData + sideData)
    #rightData = (np.sqrt(2.0)/2.0) * (midData - sideData)

    #return [leftData, rightData]

  
### Stereo Coding ###
### Masking level difference calculation ###
def MLD( z ):
    """
    Calculates the masking level difference factors for Bark frequency z
    :returns: MLD factor array for all Bark frequencies
    """
    zVec = np.arange(25)
    mld = np.zeros_like(zVec)
    indices = np.arange(25)

    mld = np.power(10.0, 1.25*(1-np.cos(np.pi * (np.minimum(z, 15.5)/15.5))) - 2.5)

    return mld
    
    
### Stereo Coding ###
### Masking threshold calculation ###
def CalcStereoMaskThresh(timeSamples, MDCTdata, MDCTscale, fs, sfBands, sendMS, isShortWindow):
    """
    Calculates the stereo masking theshold for M/S or L/R based on sendMS argument
    timeSamples, MDCTdata, MDCTscale are per channel, [leftData[], rightData[]]

    :timeSamples: Audio data per channel
    :MDCTdata: MDCT lines per channel
    :MDCTscale: Overall scale factor per channel
    :fs: Sampling rate of system
    :sfBands: Scale factor bands NOT per channel. Same for both channels.
    :sendMS: 0 if we are transmitting L/R and 1 if we are transmitting M/S
    :isShortWindow: True if we are using a short window (to tell sfBands to downshift more)
    :returns: SMR[numChannels][sfBands.nBands] is the maximum signal-to-mask
    ratio in each scale factor band per channel (in same form as above)
    """
    #  == L/R SMR calculation ==
    
    basicThresh0 = SPL( CalcBasicThresh(timeSamples[0], MDCTdata[0], MDCTscale[0], fs, sfBands, False, isShortWindow) )
    basicThresh1 = SPL( CalcBasicThresh(timeSamples[1], MDCTdata[1], MDCTscale[1], fs, sfBands, False, isShortWindow) )
    basicThresh = [basicThresh0, basicThresh1]

    # calculate MDCT SPL
    MDCTdataSpl0 = SPL_MDCT(MDCTdata[0], SineWindow(np.ones(len(timeSamples[0]))))
    MDCTdataSpl1 = SPL_MDCT(MDCTdata[1], SineWindow(np.ones(len(timeSamples[1]))))
    MDCTdataSpl = [MDCTdataSpl0, MDCTdataSpl1]

    # get max SMRs for L/R
    SMR_LR = CalcMaxSMR( basicThresh, MDCTdataSpl, sfBands )

    # == M/S SMR calculation ==

    # turn time data and MDCT data into M/S
    # (not using EncodeMS and DecodeMS here because it feels a bit wrong
    # to specify fake values for the subbands)
    timeSamplesM = (timeSamples[0] + timeSamples[1]) / 2.0#np.sqrt(2.0)
    timeSamplesS = (timeSamples[0] - timeSamples[1]) / 2.0#np.sqrt(2.0)
    timeSamplesMS = [timeSamplesM, timeSamplesS]
    MDCTdataM = (MDCTdata[0] + MDCTdata[1]) / 2.0#np.sqrt(2.0)
    MDCTdataS = (MDCTdata[0] - MDCTdata[1]) / 2.0#np.sqrt(2.0)
    MDCTdataMS = [MDCTdataM, MDCTdataS]

    # calculate MDCT SPL for M/S
    MDCTdataSplM = SPL_MDCT(MDCTdataMS[0], SineWindow(np.ones(len(timeSamplesMS[0]))))
    MDCTdataSplS = SPL_MDCT(MDCTdataMS[1], SineWindow(np.ones(len(timeSamplesMS[1]))))
    MDCTdataSplMS = [MDCTdataSplM, MDCTdataSplS]
    
    # get MDCT frequencies in Hz
    mdctHalfBlockSize = len(MDCTdata[0])
    mdctBinFreqs = (
        ((np.arange(mdctHalfBlockSize) + 0.5) / mdctHalfBlockSize) * (0.5 * fs)
        )
    
    # calculate MLD
    mld = [ ]
    freqs = [ ]
    for f in mdctBinFreqs:
        mld.append( MLD( Bark(f) ) )
        freqs.append( Bark(f) )
    # normalise 
    if not isShortWindow:
    	mld = mld/np.amax(mld)

    # calculate basic thresholds for MS (with the downshift)
    basicThreshDownM = SPL( CalcBasicThresh(timeSamplesMS[0], MDCTdataMS[0], MDCTscale[0], fs, sfBands, False, isShortWindow) )
    basicThreshDownS = SPL( CalcBasicThresh(timeSamplesMS[1], MDCTdataMS[0], MDCTscale[1], fs, sfBands, False, isShortWindow) )

    # calculate basic thresholds for MS (without the downshift)
    basicThreshM = CalcBasicThresh(timeSamplesMS[0], MDCTdataMS[0], MDCTscale[0], fs, sfBands, True, isShortWindow)
    basicThreshS = CalcBasicThresh(timeSamplesMS[1], MDCTdataMS[1], MDCTscale[1], fs, sfBands, True, isShortWindow)

    # scale by MLD (to account for a larger downshift in lower frequencies)
    mldMid = SPL( basicThreshM * mld )
    mldSide = SPL( basicThreshS * mld )


    # choose MLD thresholds over basic threshold if there is a chance of stereo unmasking
    #threshMid = np.maximum( basicThreshDownM, np.minimum( basicThreshDownS, mldSide ) )
    #threshSide = np.maximum( basicThreshDownS, np.minimum( basicThreshDownM, mldMid ) )
    BTHR = np.maximum( basicThreshDownM, basicThreshDownS )
    threshMid = np.minimum( BTHR, mldMid )
    threshSide = np.minimum( BTHR, mldSide )
    threshMS = [threshMid, threshSide]

    # get max SMRs for M/S
    SMR_MS = CalcMaxSMR( threshMS, MDCTdataSplMS, sfBands )

    #plotData( mld, freqs, MDCTdataSpl, basicThresh, SMR_LR, MDCTdataSplMS, threshMS, SMR_MS, sfBands )

    # == create overall SMR array ==
    # go through L/R SMR and M/S SMR band by band, and choose which SMR value
    # to return based on sendMS
    SMR = []
    for iCh in range(2):
        SMR.append(np.zeros_like(SMR_MS[0]))

        for i in range(sfBands.nBands):
        
            #bandLowerMDCTBinIndex = sfBands.lowerLine[i]
            #bandUpperMDCTBinIndex = sfBands.upperLine[i]+1

            if sendMS[i] == 1:
                # take M/S SMR
                SMR[iCh][i] = SMR_MS[iCh][i]
            else:
                # take L/R SMR
                SMR[iCh][i] = SMR_LR[iCh][i]
    
    return SMR

def CalcMaxSMR( stereoThresh, MDCTdataSpl, sfBands ):
    """ Helper function for CalcStereoMask Thresh
    Calculates the max SMR per band based on 2 channel masking curve
    Use for M/S or L/R

    :stereoThresh: stereo masking curve (can be M/S or L/R) [chan0[], chan1[]]
    :MDCTdataSpl: MDCT data associatd with the masking curve in SPL [MDCTchan0[], MDCTchan1[]]
    :sfBands: Scale factor bands NOT per channel. Same for both channels.
    """

    # for each channel, for each band, calculate maximum SMR for that band
    SMRs = []
    for iCh in range(2): # using 2 for two channels
        SMRs.append([])
        for i in range(sfBands.nBands):
            bandLowerMDCTBinIndex = sfBands.lowerLine[i]
            bandUpperMDCTBinIndex = sfBands.upperLine[i]+1

            # get masking curve segment for this band
            bandMasterMasker = stereoThresh[iCh][
                bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
            ]

            # get signal segment for this band
            bandxMDCT = MDCTdataSpl[iCh][bandLowerMDCTBinIndex:bandUpperMDCTBinIndex]

            # take SMR for entire band
            bandSMR = bandxMDCT - bandMasterMasker

            # Save maximum
            if len(bandSMR) == 0:
                SMRs[iCh].append(-96.0)
            else:
                SMRs[iCh].append(np.amax(bandSMR))
    
    return SMRs

def CalcBasicThresh(timeSamples, MDCTdata, MDCTscale, fs, sfBands, isMLD, isShortWindow):
    """Calculate the basic masking curves based on tonal and non-tonal maskers for one channel

    timeSamples, MDCTdata, MDCTscale are per channel, [leftData[], rightData[]]

    :timeSamples: Audio data per channel
    :MDCTdata: MDCT lines per channel
    :MDCTscale: Overall scale factor per channel
    :fs: Sampling rate of system
    :sfBands: Scale factor bands NOT per channel. Same for both channels.
    :isMLD: if 0, we are calculating the threshold for L/R, if 1, then for M/S
    :isShortWindow: 1 if short window (makes downshift go down more in vIntensityAtBark)
    :returns: masterMasker: the overall masking threshold in intensity values per frequency line
    ratio in each scale factor band per channel (in same form as above)
    """

    xWindowed = HanningWindow(timeSamples)

    fftBlockSize = len(timeSamples) #1024

    #mdctHalfBlockSize = len(MDCTdata)
    #mdctBlockSize = 2.0 * mdctHalfBlockSize
    # MDCT is already scaled in codec.py!!
    MDCTdataSpl = SPL_MDCT(MDCTdata, SineWindow(np.ones(len(timeSamples))))

    # FFT
    X = np.fft.fft(xWindowed, fftBlockSize)

    # throw away right half
    X = X[:len(X) / 2.0]

    # take SPL
    XSpl = SPL_dft(X, HanningWindow(np.ones(len(timeSamples))))

    # Frequencies of each FFT bin
    binFreqs = (np.linspace(0, np.pi, len(X)) * fs) / (2 * np.pi)

    # intensities of each FFT bin
    XIntensity = Intensity(XSpl)

    peakBinIndices = []
    peakBinSpls = []
    peakBinFrequencies = []
    peakMaskers = []

    ## Find peaks by searching for local maxima in every 3 bins
    # Create tonal maskers for each peak
    for i in range(1, len(XSpl) - 1):
        binSpl = XSpl[i]
        prevBinSpl = XSpl[i - 1]
        nextBinSpl = XSpl[i + 1]

        # Peak found
        if prevBinSpl < binSpl and nextBinSpl < binSpl:
            peakBinIndices.append(i)

            # Calculate SPL of peak by aggregating intensity across prev and
            # next bins
            binIntensity = Intensity(binSpl)
            prevBinIntensity = Intensity(prevBinSpl)
            nextBinIntensity = Intensity(nextBinSpl)
            binIntensitySum = (
                binIntensity + prevBinIntensity + nextBinIntensity
            )
            estimatedPeakSpl = SPL(binIntensitySum)
            peakBinSpls.append(estimatedPeakSpl)

            # Calculate peak frequency by taking the weighted average across
            # prev and next bins
            binFreq = binFreqs[i]
            prevBinFreq = binFreqs[i - 1]
            nextBinFreq = binFreqs[i + 1]
            estimatedPeakFreq = (
                (binFreq * binIntensity) + (prevBinFreq * prevBinIntensity) +
                (nextBinFreq * nextBinIntensity)
            ) / binIntensitySum
            peakBinFrequencies.append(estimatedPeakFreq)

            # Create a `Masker` object for each tonal peak
            peakMasker = Masker(estimatedPeakFreq, estimatedPeakSpl, True, isMLD, isShortWindow)
            peakMaskers.append(peakMasker)

    # now create noise maskers in critical bands that do not have peaks
    # centered within them.
    noiseMaskers = []
    # MDCT frequencies
    mdctHalfBlockSize = len(MDCTdata)
    mdctBinFreqs = (
        ((np.arange(mdctHalfBlockSize) + 0.5) / mdctHalfBlockSize)
        * (0.5 * fs)
    )

    # Hearing threshold in quiet for each frequency
    binThresholds = Thresh(mdctBinFreqs)

    # TODO: this doesn't have to be N^2 but I am low on time
    for i in range(sfBands.nBands):
        peakFound = False

        bandLowerFreq = mdctBinFreqs[sfBands.lowerLine[i]]
        bandUpperFreq = mdctBinFreqs[sfBands.upperLine[i]]

        for j in range(len(peakBinFrequencies)):
            peakFreq = peakBinFrequencies[j]

            # if peak is in current band
            if peakFreq > bandLowerFreq and peakFreq < bandUpperFreq:
                peakFound = True
                break

        # if a peak was not found in this band, create a noise masker for
        # the band
        if not peakFound:

            # find intensity of spectrum within this band by summing
            # intensities and center frequency of spectrum within this
            # band using a weighted average
            intensitySum = 0.0
            weightedSum = 0.0
            for binIndex in range(len(binFreqs)):
                binFreq = binFreqs[binIndex]
                binIntensity = XIntensity[binIndex]
                if binFreq >= bandLowerFreq and binFreq <= bandUpperFreq:
                    intensitySum += binIntensity
                    weightedSum += (binIntensity * binFreq)

                if binFreq > bandUpperFreq:
                    break

            if intensitySum != 0.0:
                maskerCenterFreq = weightedSum / intensitySum
                maskerSpl = SPL(intensitySum)

                noiseMasker = Masker(
                    maskerCenterFreq,
                    maskerSpl,
                    False,
                    isMLD,
		    isShortWindow
                )
                noiseMaskers.append(noiseMasker)

    # Barks for MDCT bin frequencies
    binBarks = Bark(mdctBinFreqs)
    #binBarks = Bark(binFreqs)

    # now the master masking function which is adding the intensities
    # of all the maskers
    masterMasker = np.zeros(len(mdctBinFreqs))


    # Trying addition of masking with alpha = 1.0
    alpha = 1.0
    # for each noise masker
    for noiseMasker in noiseMaskers:
        noiseMaskerResponse = noiseMasker.vIntensityAtBark(binBarks)
        masterMasker += noiseMaskerResponse**alpha
    # for each tonal masker
    for tonalMasker in peakMaskers:
        tonalMaskerResponse = tonalMasker.vIntensityAtBark(binBarks)
        masterMasker += tonalMaskerResponse**alpha
    # for threshold in quiet
    masterMasker += (Intensity(binThresholds))**alpha
    masterMasker = masterMasker**(1.0/alpha)

            
    # for each noise masker
    #for noiseMasker in noiseMaskers:
    #    noiseMaskerResponse = noiseMasker.vIntensityAtBark(binBarks)
    #    masterMasker += noiseMaskerResponse
        
    masterMasker += Intensity(binThresholds)
    #masterMasker = SPL(masterMasker)

    return masterMasker 
    

def CalcSMRs(timeSamples, MDCTdata, MDCTscale, fs, sfBands):
    """Calculate the masking curves.

    timeSamples, MDCTdata, MDCTscale are per channel, [leftData[], rightData[]]

    :timeSamples: Audio data per channel
    :MDCTdata: MDCT lines per channel
    :MDCTscale: Overall scale factor per channel
    :fs: Sampling rate of system
    :sfBands: Scale factor bands NOT per channel. Same for both channels.
    :returns: SMR[numChannels][sfBands.nBands] is the maximum signal-to-mask
    ratio in each scale factor band per channel (in same form as above)
    """
    SMR = [
        CalcSMRsSingleChannel(
            timeSamples[0], MDCTdata[0], MDCTscale[0], fs, sfBands
        ),
        CalcSMRsSingleChannel(
            timeSamples[1], MDCTdata[1], MDCTscale[1], fs, sfBands
        )
    ]

    return SMR
 
def CalcSMRsSingleChannel(x, MDCTdata, MDCTscale, fs, sfBands):
    """
    Set SMR for each critical band in sfBands.
    :x: an array of N time domain samples
    :MDCTdata: an array of N/2 MDCT frequency lines for the data in data which
    have been scaled up by a factor of 2^MDCTscale
    :MDCTscale: an overall scale factor for the set of MDCT frequency lines
    :sampleRate: is the sampling rate of the time domain samples
    :sfBands: points to information about which MDCT frequency lines are in
    which scale factor band
    :returns: SMR[sfBands.nBands] is the maximum signal-to-mask ratio in each
    scale factor band
    Logic:  Performs an FFT of data[N] and identifies tonal and noise maskers.
            Sums their masking curves with the hearing threshold at each MDCT
            frequency location to the calculate absolute threshold at those
            points. Then determines the maximum signal-to-mask ratio within
            each critical band and returns that result in the SMR[] array.
    """

    xWindowed = HanningWindow(x)

    fftBlockSize = len(x) #1024

    #mdctHalfBlockSize = len(MDCTdata)
    #mdctBlockSize = 2.0 * mdctHalfBlockSize
    MDCTdataSpl = SPL_MDCT(MDCTdata*MDCTscale, SineWindow(np.ones(len(x))))

    # FFT
    X = np.fft.fft(xWindowed, fftBlockSize)

    # throw away right half
    X = X[:len(X) / 2.0]

    # take SPL
    XSpl = SPL_dft(X, HanningWindow(np.ones(len(x))))

    # Frequencies of each FFT bin
    binFreqs = (np.linspace(0, np.pi, len(X)) * fs) / (2 * np.pi)

    # intensities of each FFT bin
    XIntensity = Intensity(XSpl)

    peakBinIndices = []
    peakBinSpls = []
    peakBinFrequencies = []
    peakMaskers = []

    ## Find peaks by searching for local maxima in every 3 bins
    # Create tonal maskers for each peak
    for i in range(1, len(XSpl) - 1):
        binSpl = XSpl[i]
        prevBinSpl = XSpl[i - 1]
        nextBinSpl = XSpl[i + 1]

        # Peak found
        if prevBinSpl < binSpl and nextBinSpl < binSpl:
            peakBinIndices.append(i)

            # Calculate SPL of peak by aggregating intensity across prev and
            # next bins
            binIntensity = Intensity(binSpl)
            prevBinIntensity = Intensity(prevBinSpl)
            nextBinIntensity = Intensity(nextBinSpl)
            binIntensitySum = (
                binIntensity + prevBinIntensity + nextBinIntensity
            )
            estimatedPeakSpl = SPL(binIntensitySum)
            peakBinSpls.append(estimatedPeakSpl)

            # Calculate peak frequency by taking the weighted average across
            # prev and next bins
            binFreq = binFreqs[i]
            prevBinFreq = binFreqs[i - 1]
            nextBinFreq = binFreqs[i + 1]
            estimatedPeakFreq = (
                (binFreq * binIntensity) + (prevBinFreq * prevBinIntensity) +
                (nextBinFreq * nextBinIntensity)
            ) / binIntensitySum
            peakBinFrequencies.append(estimatedPeakFreq)

            # Create a `Masker` object for each tonal peak
            peakMasker = Masker(estimatedPeakFreq, estimatedPeakSpl, True)
            peakMaskers.append(peakMasker)

    # now create noise maskers in critical bands that do not have peaks
    # centered within them.
    noiseMaskers = []
    # MDCT frequencies
    mdctHalfBlockSize = len(MDCTdata)
    mdctBinFreqs = (
        ((np.arange(mdctHalfBlockSize) + 0.5) / mdctHalfBlockSize)
        * (0.5 * fs)
    )

    # Hearing threshold in quiet for each frequency
    binThresholds = Thresh(mdctBinFreqs)

    # TODO: this doesn't have to be N^2 but I am low on time
    for i in range(sfBands.nBands):
        peakFound = False

        bandLowerFreq = mdctBinFreqs[sfBands.lowerLine[i]]
        bandUpperFreq = mdctBinFreqs[sfBands.upperLine[i]]

        for j in range(len(peakBinFrequencies)):
            peakFreq = peakBinFrequencies[j]

            # if peak is in current band
            if peakFreq > bandLowerFreq and peakFreq < bandUpperFreq:
                peakFound = True
                break

        # if a peak was not found in this band, create a noise masker for
        # the band
        if not peakFound:

            # find intensity of spectrum within this band by summing
            # intensities and center frequency of spectrum within this
            # band using a weighted average
            intensitySum = 0.0
            weightedSum = 0.0
            for binIndex in range(len(binFreqs)):
                binFreq = binFreqs[binIndex]
                binIntensity = XIntensity[binIndex]
                if binFreq >= bandLowerFreq and binFreq <= bandUpperFreq:
                    intensitySum += binIntensity
                    weightedSum += (binIntensity * binFreq)

                if binFreq > bandUpperFreq:
                    break

            if intensitySum != 0.0:
                maskerCenterFreq = weightedSum / intensitySum
                maskerSpl = SPL(intensitySum)

                noiseMasker = Masker(
                    maskerCenterFreq,
                    maskerSpl,
                    False
                )
                noiseMaskers.append(noiseMasker)

    # Barks for MDCT bin frequencies
    binBarks = Bark(mdctBinFreqs)
    #binBarks = Bark(binFreqs)

    # now the master masking function which is adding the intensities
    # of all the maskers
    masterMasker = np.zeros(len(mdctBinFreqs))
    # for each noise masker
    for noiseMasker in noiseMaskers:
        noiseMaskerResponse = noiseMasker.vIntensityAtBark(binBarks)
        masterMasker += noiseMaskerResponse

    # for each tonal masker
    for tonalMasker in peakMaskers:
        tonalMaskerResponse = tonalMasker.vIntensityAtBark(binBarks)
        masterMasker += tonalMaskerResponse

    masterMasker += Intensity(binThresholds)
    masterMasker = SPL(masterMasker)

    # and take maximum with threshold of hearing curve
    #masterMasker = np.maximum(masterMasker, binThresholds)

    # for each band, calculate maximum SMR for that band
    SMRs = []
    for i in range(sfBands.nBands):
        bandLowerMDCTBinIndex = sfBands.lowerLine[i]
        bandUpperMDCTBinIndex = sfBands.upperLine[i]

        # get masking curve segment for this band
        bandMasterMasker = masterMasker[
            bandLowerMDCTBinIndex:bandUpperMDCTBinIndex
        ]

        # get signal segment for this band
        bandxMDCT = MDCTdataSpl[bandLowerMDCTBinIndex:bandUpperMDCTBinIndex]

        # take SMR for entire band
        bandSMR = bandxMDCT - bandMasterMasker

        # Save maximum
        SMRs.append(np.amax(bandSMR))

    #pylab.figure()
    #pylab.semilogx(mdctBinFreqs, MDCTdataSpl)
    #for bandLowerIndex in sfBands.lowerLine:
        #bandLowerFreq = mdctBinFreqs[bandLowerIndex]
        #pylab.vlines(bandLowerFreq, -10, 100)
    #pylab.show()

    return np.array(SMRs)


def plotData( mld, freqs, MDCTdataSPL, threshLR, SMR_LS, MDCTdataSPLMS, threshMS, SMR_MS, sfBands ):
    """ function to call from CalcStereoMaskThresh to plot
    various things
    """

    # == plot mld as a function of the MDCT frequencies ==
    plt.figure(1)
    plt.plot(freqs,mld)
    plt.xlabel('Frequency (Barks)')
    plt.ylabel('MLD( Bark(freq) )')
    plt.ylim(0, 1.01)
    plt.title('Masking Level Difference factor as a function of MDCT frequencies')

    # == Plot L/R SPL, curve, and SMR ==
    plt.figure(2)
    plt.subplot(211)
    pltMDCT ,= plt.semilogx( MDCTdataSPL[0], 'k' )
    pltThresh ,= plt.semilogx( threshLR[0], 'r' )
    plt.bar(sfBands.lowerLine, SMR_LS[0], sfBands.nLines, alpha=0.6)
    plt.legend([pltMDCT, pltThresh], ["signal MDCT SPL", "Overall Masking Threshold"])
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('left channel SPL (dB)')
    plt.title('SPL of MDCT encoded as left and right with masking curve and SMRs')
    plt.subplot(212)
    plt.semilogx( MDCTdataSPL[1], 'k' )
    plt.semilogx( threshLR[1], 'r' )
    plt.bar(sfBands.lowerLine, SMR_LS[1], sfBands.nLines, alpha=0.6)
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('right channel SPL (dB)')

    # == Plot M/S SPL, curve, and SMR == 
    plt.figure(3)
    plt.subplot(211)
    pltMDCT ,= plt.semilogx( MDCTdataSPLMS[0], 'k' )
    pltThresh ,= plt.semilogx( threshMS[0], 'r' )
    plt.bar(sfBands.lowerLine, SMR_MS[0], sfBands.nLines, alpha=0.6)
    plt.legend([pltMDCT, pltThresh], ["signal MDCT SPL", "Overall Masking Threshold"])
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('mid channel SPL (dB)')
    plt.title('SPL of MDCT encoded as mid and side with masking curve and SMRs')
    plt.subplot(212)
    plt.semilogx( MDCTdataSPLMS[1], 'k' )
    plt.semilogx( threshMS[1], 'r' )
    plt.bar(sfBands.lowerLine, SMR_MS[1], sfBands.nLines, alpha=0.6)
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('side channel SPL (dB)')

    
    plt.show()
