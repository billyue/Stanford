import numpy as np
from huffman import *

input = [64,64,64,0,0,0,64,0,64,0,64,0]

h1, saved1 = EncodeHuffman(input,11)
huffmanEncoded = h1

pb = PackedBits()
pb.Size(len(huffmanEncoded)/8 + 1)
for bit in huffmanEncoded:
    pb.WriteBits(int(bit),1)
pb.ResetPointers()

o1 = DecodeHuffman(pb, 11, len(input))

print o1

#print saved1


#string = '000110110000000000000010010000000010101010001'
#
#encodedString, savings = EncodeBinaryStringInPairs(string)
#
#pb = PackedBits()
#pb.Size(len(encodedString)/8 + 1)
#for bit in encodedString:
#    pb.WriteBits(int(bit),1)
#pb.ResetPointers()
#
#decodedString = DecodeBinaryStringInPairsFromData(pb)
##decodedString = DecodeBinaryStringInPairs(encodedString)
#
##print string
##print decodedString
#if decodedString == string:
#    print 'suxes, savings:', savings
#else:
#    print 'fail'
