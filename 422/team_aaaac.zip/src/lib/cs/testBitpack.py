from bitpack import *

pb = PackedBits()
pb.Size(1)
#print pb.GetPackedData()
#pb.SetPackedData("111")
#print pb.GetPackedData()
pb.WriteBits(2,2)
pb.WriteBits(3,2)
pb.ResetPointers()
print pb.ReadBits(2)
print pb.ReadBits(2)

#pb.WriteBits(7,3)
#print pb.GetPackedData()
