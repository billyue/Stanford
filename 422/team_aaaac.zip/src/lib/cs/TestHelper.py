import unittest
import numpy as np


class TestHelper(unittest.TestCase):
    """Base class for stuff usually required for test classes."""

    def setUp(self):
        """Runs before each test."""
        pass

    def tearDown(self):
        """Runs after each test"""
        pass

    def ensure_values_equal(
            self, actualResult, expectedResult, errorContext, atol=1e-08):
        """Ensure two values have the same type and are close enough to the
        same value.

        :actualResult: @todo
        :expectedResult: @todo
        :returns: @todo

        """

        self.assertEqual(
            type(expectedResult),
            type(actualResult),
            """Types for `{}` were not the same.  Result was `{}` but expected
to be `{}`""".format(errorContext, type(actualResult), type(expectedResult))
        )

        self.assertTrue(
            np.allclose(expectedResult, actualResult, atol=atol),
            """Result for `{}` was not the same.  Value was `{}` but was
expected to be `{}`""".format(errorContext, actualResult, expectedResult)
        )

    def ensure_vectors_equal(
            self, actualResult, expectedResult, errorContext=None, atol=1e-08):
        """Ensure two vectors have the same type, their elements are the same
        type, and their values are close enough.

        :actualResult: @todo
        :expectedResult: @todo
        :errorContext: @todo
        :returns: @todo

        """
        if errorContext:
            errorContextMessage = "Vectors unequal for {}.  ".format(
                errorContext
            )
        else:
            errorContextMessage = ""

        self.assertEqual(
            type(expectedResult),
            type(actualResult),
            "{}Type of result was `{}` but expected to be `{}`".format(
                errorContextMessage,
                type(actualResult),
                type(expectedResult)
            )
        )

        self.assertEqual(
            type(expectedResult[0]),
            type(actualResult[0]),
            "{}Type of first result was `{}` but expected to be `{}`".format(
                errorContextMessage,
                type(actualResult[0]),
                type(expectedResult[0])
            )
        )

        # ensure same size
        self.assertEqual(
            len(expectedResult),
            len(actualResult),
            """{}Size of result was `{}` but expected to be `{}`.  Got:
    {}

but expected:

    {}
"""
            .format(
                errorContextMessage,
                len(expectedResult),
                len(actualResult),
                actualResult,
                expectedResult
            )
        )

        self.assertTrue(
            np.allclose(actualResult, expectedResult, atol=atol),
            """{}Vectors were not close enough.  Got:\n\t{}\nbut was expecting
\n\t{}\n\n""".format(errorContextMessage, actualResult, expectedResult)
        )

    def run_scalar_test(self, method, vendorMethod, scalars):
        """Compare expected results to actual results of executing `method`
        on individual values.

        :method: @todo
        :scalars: @todo
        :expectedResults: @todo
        :returns: @todo

        """
        for i in range(0, len(scalars)):
            scalar = scalars[i]
            expectedResult = vendorMethod(scalar)
            actualResult = method(scalar)

            self.ensure_values_equal(actualResult, expectedResult, scalar)

    def run_vector_test(self, method, vendorMethod, vector):
        """Compare expected results to actual results of executing `method`
        on the provided vector.

        :method: @todo
        :vector: @todo
        :expectedVector: @todo
        :returns: @todo

        """
        results = method(vector)
        expectedVector = vendorMethod(vector)

        self.ensure_vectors_equal(
            results,
            expectedVector
        )
