###
#   @file       mdct.py
#
#               Methods for computing the Modified Discrete Cosine Transform
#               (MDCT) as defined in Bossi's book.
#
#   @author     Colin Sullivan <colin [at] colin-sullivan.net>
#
#               Copyright (c) 2013 Colin Sullivan
#               Licensed under the MIT license.
###


import numpy as np


def MDCTslow(data, a, b, isInverse=False):
    """
    Slow MDCT algorithm for window length a+b following pp. 130 of Bosi &
    Goldberg, "Introduction to Digital Audio..." book (and where 2/N factor is
    included in forward transform instead of inverse).

    :data: transform this data
    :a: left half-window length
    :b: right half-window length
    :isInverse: If we should take the inverse transform of the data
    :returns: transformed or inverse transformed data.
    """

    N = a + b
    twoPIOverN = ((2 * np.pi) / N)
    n0 = (b + 1) / 2

    if isInverse is False:

        X = np.zeros(N/2)

        for k in range(int(N/2)):
            for n in range(int(N)):
                X[k] += data[n] * np.cos(
                    twoPIOverN * (n + n0) * (k + 0.5)
                )

            X[k] *= (2 / N)

        return X
    else:
        x = np.zeros(N)

        for n in range(int(N)):
            for k in range(int(N/2)):
                x[n] += data[k] * np.cos(
                    twoPIOverN * (n + n0) * (k + 0.5)
                )
            x[n] *= 2.0

        return x


def IMDCTslow(data, a, b):
    """Inverse slow MDCT.

    :returns: Inverse transformed data.
    """
    return MDCTslow(data, a, b, True)


def MDCT(data, a, b, isInverse=False):
    """
    Fast MDCT algorithm for window length a+b following pp. 141-143 of Bosi &
    Goldberg, "Introduction to Digital Audio..." book (and where 2/N factor is
    included in forward transform instead of inverse).

    :data: transform this data
    :a: left half-window length
    :b: right half-window length
    :isInverse: If we should take the inverse transform of the data
    :returns: transformed or inverse transformed data.
    """
    N = int(a + b)
    n0 = (b + 1.0) / 2.0

    if isInverse is False:

        # Create a vector of values for pre-twiddling
        # (e^{(-j * 2 * pi * n)/(2N)})
        preTwiddleVec = np.exp(np.linspace(0, N - 1, N) * ((-1j * np.pi) / N))

        preTwiddledData = data * preTwiddleVec

        X = np.fft.fft(preTwiddledData, N)[:-(N/2)]

        postTwiddleVec = np.exp(
            (np.linspace(0, (N/2) - 1, (N/2)) + 0.5) * n0 * (
                (-1j * 2.0 * np.pi) / N
            )
        )

        postTwiddledData = (2.0 / N) * np.real(X * postTwiddleVec)

        return postTwiddledData
    else:
        # Pre-twiddle the frequency samples by multipling with
        # e^{(j2\pi k n_0)/N}
        preTwiddleVec = np.exp(
            np.linspace(0, N - 1, N) * n0 * ((1.0j * 2.0 * np.pi) / N)
        )

        # X[N - 1 - k] = -X[k] for k \geq N/2
        X = np.append(data, -1.0 * data[::-1])

        # Apply pre-twiddling
        X = X * preTwiddleVec

        x = np.fft.ifft(X, N)

        # post twiddle inverse transformed data by taking the real part
        # of the inverse transformed data times the factor
        # e^{(j2\pi * (n + n0) / 2N)}
        postTwiddleVec = np.exp(
            (1.0j * np.pi * (np.linspace(0, N - 1, N) + n0)) / N
        )

        # apply post twiddling
        x = N * x * postTwiddleVec

        return np.real(x)


def IMDCT(data, a, b):
    """Inverse fast MDCT.

    :returns: Inverse transformed data.
    """
    return MDCT(data, a, b, True)
