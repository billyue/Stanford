#!/usr/bin/env python
# encoding: utf-8

from optparse import OptionParser
import os
import json
import logging

from src.pacfile import encode_and_decode

if __name__ == "__main__":

    argParser = OptionParser(
        usage="usage: %prog [options] inDirectory/ outDirectory/"
    )

    (options, args) = argParser.parse_args()

    if len(args) == 2:
        inDirectoryPath = args[0]
        outDirectoryPath = args[1]
    else:
        argParser.print_help()
        exit(-1)

    logging.basicConfig(
        filename=os.path.join(outDirectoryPath, "encode.log"),
        level=logging.DEBUG
    )

    # path to all input files
    inputFiles = os.listdir(inDirectoryPath)

    allStats = []

    # For each input file, encode and decode
    for inputFileName in inputFiles:
        inputFilePath = os.path.join(
            inDirectoryPath, inputFileName
        )

        stats = {
            "inputFile": inputFilePath,
            "encodes": []
        }

        # for each bitrate
        for bitrate in [128]:

            logging.debug("Processing {} at {}kbps".format(
                inputFilePath,
                bitrate
            ))

            encodeStats = {
                "bitrate": bitrate,
            }

            outputFilePath = os.path.join(
                outDirectoryPath,
                (
                    inputFileName[:-4]
                    + "_decoded_{}kbps.wav".format(bitrate)
                )
            )

            encodeStats["outputFilePath"] = outputFilePath

            codedFilePath = (
                outputFilePath[:-4]
                + ".aaaac"
            )

            encodeStats["codedFilePath"] = codedFilePath

            try:
                times = encode_and_decode(
                    inputFilePath,
                    codedFilePath,
                    outputFilePath,
                    bitrate,
                )

                encodeStats["encodeTime"] = times[0]
                encodeStats["decodeTime"] = times[1]

                compressionRatio = (
                    float(os.path.getsize(inputFilePath))
                    / float(os.path.getsize(codedFilePath))
                )
                encodeStats["compressionRatio"] = compressionRatio

            except Exception as e:
                encodeStats["failedWithError"] = str(e)
                logging.exception("Failed while encoding or decoding.")

            stats["encodes"].append(encodeStats)

        allStats.append(stats)

    # Path to statistics file
    statsFile = open(os.path.join(outDirectoryPath, "stats.json"), "w")

    statsFile.write(json.dumps(
        allStats,
        indent=4
    ))

    statsFile.close()
