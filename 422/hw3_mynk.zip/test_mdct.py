import unittest

import m as vendormdct
import mdct

import numpy as np


class TestMDCTMethods(unittest.TestCase):
    """Tests MDCT methods on a test signal."""

    def setUp(self):
        """Initialize data for tests.
        :returns: @todo

        """

        self.signal = np.asarray([
            0.0,
            1.0,
            2.0,
            3.0,
            4.0,
            4.0,
            4.0,
            4.0,
            3.0,
            1.0,
            -1.0,
            -3.0
        ])

        self.blockSize = 8
        self.halfBlockSize = 0.5 * self.blockSize

        self.signalHalfBlocks = np.array_split(
            self.signal,
            self.halfBlockSize - 1
        )

        self.signalOverlappedBlocks = []

        prevHalfBlock = np.zeros(self.halfBlockSize)
        for halfBlock in self.signalHalfBlocks:

            self.signalOverlappedBlocks.append(
                np.append(prevHalfBlock, halfBlock)
            )

            prevHalfBlock = halfBlock

        # last block
        self.signalOverlappedBlocks.append(
            np.append(prevHalfBlock, np.zeros(self.halfBlockSize))
        )

        self.signalOverlappedBlocks = np.asarray(self.signalOverlappedBlocks)

        #print("self.signalOverlappedBlocks")
        #print(self.signalOverlappedBlocks)

    def ensure_reconstructed_correctly(self, MDCT, IMDCT):
        """Loop over blocks, transform and de-transform using the provided
        methods, then ensure output signal is original signal reconstructed.

        :MDCT: @todo
        :IMDCT: @todo
        :returns: @todo

        """
        decodedSignal = None

        for block in self.signalOverlappedBlocks:
            transformed = MDCT(
                block,
                self.halfBlockSize,
                self.halfBlockSize
            )
            deTransformed = IMDCT(
                transformed,
                self.halfBlockSize,
                self.halfBlockSize
            )

            # apply synthesis window
            deTransformedWindowed = 0.5 * deTransformed

            #print("deTransformedWindowed")
            #print(deTransformedWindowed)

            if decodedSignal is None:
                decodedSignal = deTransformedWindowed[self.halfBlockSize:]
            else:
                # Overlap incoming block
                toAdd = np.append(
                    np.zeros(len(decodedSignal) - self.halfBlockSize),
                    deTransformedWindowed
                )

                #print("toAdd")
                #print(toAdd)

                # Add into decoded signal

                decodedSignal = np.append(
                    decodedSignal, np.zeros(self.halfBlockSize)
                ) + toAdd

            #print("decodedSignal")
            #print(decodedSignal)

        # Throw away last block's padding samples
        decodedSignal = decodedSignal[:-self.halfBlockSize]

        #print("decodedSignal")
        #print(decodedSignal)

        self.assertTrue(np.allclose(decodedSignal, self.signal))

    def test_MDCT_vendor(self):
        """Test Bossi's MDCT functionality.
        :returns: @todo

        """
        self.ensure_reconstructed_correctly(vendormdct.MDCT, vendormdct.IMDCT)

    def test_MDCTslow(self):
        """Test MDCTslow results.
        :returns: @todo

        """

        # Ensure MDCTslow returns same values as vendor
        myTransformedBlock = mdct.MDCTslow(
            self.signalOverlappedBlocks[0],
            self.halfBlockSize,
            self.halfBlockSize
        )

        vendorTransformedBlock = vendormdct.MDCT(
            self.signalOverlappedBlocks[0],
            self.halfBlockSize,
            self.halfBlockSize
        )

        self.assertEqual(
            type(myTransformedBlock),
            type(vendorTransformedBlock)
        )

        self.assertEqual(
            type(myTransformedBlock[0]),
            type(vendorTransformedBlock[0])
        )

        self.assertEqual(
            len(myTransformedBlock),
            len(vendorTransformedBlock),
            "Length was `{}` but should have been `{}`".format(
                len(myTransformedBlock),
                len(vendorTransformedBlock)
            )
        )

        self.assertTrue(
            np.allclose(myTransformedBlock, vendorTransformedBlock),
            """Values were not close enough.  Supposed to be:
                {}
            but got
                {}
            """.format(vendorTransformedBlock, myTransformedBlock)
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
