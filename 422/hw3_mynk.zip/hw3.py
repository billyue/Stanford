from pcmfile import *
from quantize import *
from window import *
from mdct import *
import numpy as np
import matplotlib.pyplot as plt

# create the audio file objects of the appropriate audioFile type
inFile= PCMFile("input.wav")
outFile = PCMFile("output.wav")

# open input file and get its coding parameters
codingParams= inFile.OpenForReading()

# set additional coding parameters that are needed for encoding/decoding
codingParams.nSamplesPerBlock = 512

# open the output file for writing, passing needed format/data parameters
outFile.OpenForWriting(codingParams)

# uniform
## Read the input file and pass its data to the output file to be written

# Initialize arrays

priorBlock = []
overlapAndAdd = []

for iCh in range(codingParams.nChannels):
    temp = []
    for iSample in range(codingParams.nSamplesPerBlock):
        temp.append(0)
    priorBlock.append(temp)
    overlapAndAdd.append(temp)
flag = True
firstBlock = True

while flag:
    data=inFile.ReadDataBlock(codingParams)
    if not data:
        flag = False  # we hit the end of the input file
        data = []
        for iCh in range(codingParams.nChannels):
            temp = []
            for iSample in range(codingParams.nSamplesPerBlock):
                temp.append(0)
            data.append(temp)

    for iCh in range(codingParams.nChannels):
        priorBlock[iCh] = np.array(priorBlock[iCh])
        data[iCh] = np.array(data[iCh])
        currentBlock = np.concatenate([priorBlock[iCh],data[iCh]])
        priorBlock[iCh] = data[iCh]
        currentBlock = SineWindow(currentBlock)
        currentBlock = MDCT(currentBlock,codingParams.nSamplesPerBlock,codingParams.nSamplesPerBlock)
        # 8 bit MT
        currentBlock = vQuantizeUniform(currentBlock,8)
        currentBlock = vDequantizeUniform(currentBlock,8)
        # FP quant
#        for iSample in range(codingParams.nSamplesPerBlock):
#            scale = ScaleFactor(currentBlock[iSample])
#            mantissa = MantissaFP(currentBlock[iSample], scale)
#            currentBlock[iSample] = DequantizeFP(scale, mantissa)

        currentBlock = IMDCT(currentBlock,codingParams.nSamplesPerBlock,codingParams.nSamplesPerBlock)
        currentBlock = SineWindow(currentBlock)
        data[iCh] = (currentBlock[0:len(currentBlock)/2] + overlapAndAdd[iCh])
        overlapAndAdd[iCh] = currentBlock[len(currentBlock)/2:len(currentBlock)]
    if not firstBlock:
        outFile.WriteDataBlock(data,codingParams)
    else:
        firstBlock = False
# end loop over reading/writing the blocks

# close the files

inFile.Close(codingParams)
outFile.Close(codingParams)

    print "Frequency domain quantization sounds spectral, as opposed to time domain quantization, which sounds like a louder noise floor. Frequency domain quantization sounds like it has smoothed out frequencies in each block which become more noticable at high block sizes"