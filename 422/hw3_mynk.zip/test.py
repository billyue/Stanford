import m
import mdct
#import mdct_tim as m
import numpy as np
import window
import w

#data1 = [0,0,0,0,0,0,0,1]
data2 = np.array([0,-1,2,3,-3,4,4,-4])
#data3 = [4,4,4,4,3,1,-1,-3]
#data4 = [3,1,-1,-3,0,0,0,0]
#
print m.MDCT(data2, 4, 4)
print mdct.MDCTslow(data2, 4, 4)
#print mdct.MDCT(data2, 4, 4)
#
##print m.MDCT(data2, 8, 8, 1)
##print mdct.MDCTslow(data2, 4, 4, 1)
##print mdct.MDCT(data2, 8, 8,1 )
#
##print np.divide(a,b)
#

#print window.HanningWindow(data2)
#print w.HanningWindow(data2)
